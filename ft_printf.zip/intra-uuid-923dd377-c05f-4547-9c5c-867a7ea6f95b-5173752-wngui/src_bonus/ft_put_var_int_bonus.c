/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_int_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:54:50 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:54:53 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_var_int(int var, char prefix, int width, bool silent)
{
	int						len;
	unsigned int			var_unsigned;

	len = 0;
	var_unsigned = var;
	if (var < 0)
		var_unsigned = -var;
	if (prefix)
	{
		if (!silent)
			ft_put_var_char(prefix);
		len++;
		if (width > 0)
			width--;
	}
	len += ft_put_var_int_unsigned(var_unsigned, width, silent);
	return (len);
}
