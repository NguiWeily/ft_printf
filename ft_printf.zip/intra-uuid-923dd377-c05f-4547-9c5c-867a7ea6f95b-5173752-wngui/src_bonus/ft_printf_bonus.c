/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:52:39 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:52:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_printf(const char *s, ...)
{
	int				len;
	int				len_inc;
	va_list			args;

	len = 0;
	va_start(args, s);
	while (*s)
	{
		len_inc = 1;
		if (*s == '%')
			len_inc = ft_put_fmt(&s, args);
		else
			ft_put_var_char(*s);
		if (len_inc < 0)
			len = -1;
		else if (len >= 0)
			len += len_inc;
		s++;
	}
	va_end(args);
	return (len);
}
