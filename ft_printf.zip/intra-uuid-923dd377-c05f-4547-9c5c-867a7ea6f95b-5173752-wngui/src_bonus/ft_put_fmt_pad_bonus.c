/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_pad_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:18:07 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:18:10 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_pad(t_options *options, bool left)
{
	int		len;

	if (left && options -> flag_left)
		return (0);
	len = 0;
	while (options -> width-- > 0)
	{
		ft_put_var_char(' ');
		len++;
	}
	return (len);
}
