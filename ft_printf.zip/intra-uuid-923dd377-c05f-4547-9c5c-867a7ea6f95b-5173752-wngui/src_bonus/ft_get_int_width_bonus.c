/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_int_width_bonus.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:55:15 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:55:23 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

static int	ft_get_int_width_helper(int offset, t_options *options)
{
	int	width;

	width = 0;
	if (options -> precision >= 0 || options -> flag_zero)
	{
		if (options -> flag_zero)
			options -> flag_left = false;
		if (options -> precision >= 0)
		{
			width = options -> precision + offset;
			if (options -> precision >= options -> width)
			{
				options -> width = options -> precision + offset;
				if (options -> precision == options -> width)
					width = options -> width;
			}
		}
		else
		{
			width = options -> width;
			options -> width = 0;
		}
	}
	return (width);
}

int	ft_get_int_width(bool negative, t_options *options)
{
	int		width;
	int		offset;

	width = 0;
	offset = (negative || options -> flag_sign || options -> flag_spce);
	width = ft_get_int_width_helper(offset, options);
	return (width);
}
