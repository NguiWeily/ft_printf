/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_p_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:53:32 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:53:34 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_p(va_list args, t_options *options)
{
	unsigned long	p;
	int				len;

	p = va_arg(args, unsigned long long);
	if (!p)
		return (ft_put_fmt_str("(nil)", options));
	len = ft_put_var_hex(p, 0, false, true);
	options -> width -= len + 2;
	len = ft_put_fmt_pad(options, true);
	len += ft_put_var_str("0x", -1, false);
	len += ft_put_var_hex(p, 0, false, false);
	return (len);
}
