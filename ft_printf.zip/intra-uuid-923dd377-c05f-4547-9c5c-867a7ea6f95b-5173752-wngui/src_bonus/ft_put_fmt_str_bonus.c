/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_str_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:53:59 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:54:01 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_str(char *str, t_options *options)
{
	int		len;

	len = ft_put_var_str(str, options -> precision, true);
	options -> width -= len;
	len = ft_put_fmt_pad(options, true);
	len += ft_put_var_str(str, options -> precision, false);
	return (len);
}
