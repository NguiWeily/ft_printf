/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_hex_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:20:26 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:20:28 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_var_hex(unsigned long var, int width, bool capital, bool silent)
{
	int		len;
	char	*charset;

	if (var == 0 && width < 0)
		return (0);
	len = 1;
	if (capital)
		charset = "0123456789ABCDEF";
	else
		charset = "0123456789abcdef";
	if (width > 0)
		width -= ft_put_var_hex(var, 0, capital, true);
	while (width-- > 0)
	{
		if (!silent)
			ft_put_var_char('0');
		len++;
	}
	if (var >= 16)
		len += ft_put_var_hex(var / 16, 0, capital, silent);
	if (!silent)
		write(1, &charset[var % 16], 1);
	return (len);
}
