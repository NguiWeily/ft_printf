/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_int_unsigned_bonus.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:58:28 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:58:31 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_var_int_unsigned(unsigned int var, int width, bool silent)
{
	int						len;

	if (var == 0 && width < 0)
		return (0);
	len = 0;
	if (width > 0)
		width -= ft_put_var_int_unsigned(var, 0, true);
	while (width-- > 0)
	{
		if (!silent)
			ft_put_var_char('0');
		len++;
	}
	if (var >= 10)
		len += ft_put_var_int_unsigned(var / 10, 0, silent);
	if (!silent)
		ft_put_var_char((char)(var % 10 + '0'));
	return (len + 1);
}
