/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_str_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:20:54 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:20:57 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_var_str(char *var, int precision, bool silent)
{
	int	len;

	len = 0;
	while (var[len] && (precision < 0 || len < precision))
	{
		if (!silent)
			ft_put_var_char(var[len]);
		len++;
	}
	return (len);
}
