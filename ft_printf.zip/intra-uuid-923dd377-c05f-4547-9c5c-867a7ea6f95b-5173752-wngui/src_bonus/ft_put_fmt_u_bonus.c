/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_u_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:57:33 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:57:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_u(va_list args, t_options *options)
{
	unsigned int	u;
	int				width;
	int				len;

	u = va_arg(args, unsigned int);
	if (u == 0 && options -> precision == 0)
		width = -1;
	else
		width = ft_get_int_width(false, options);
	len = ft_put_var_int_unsigned(u, width, true);
	options -> width -= len;
	len = ft_put_fmt_pad(options, true);
	len += ft_put_var_int_unsigned(u, width, false);
	return (len);
}
