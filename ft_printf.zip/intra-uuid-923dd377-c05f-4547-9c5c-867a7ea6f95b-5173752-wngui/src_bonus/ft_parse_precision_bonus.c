/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_precision_bonus.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:55:38 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:55:40 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

void	ft_parse_precision(const char **s, va_list args, t_options *options)
{
	if (**s == '.')
	{
		options -> precision = 0;
		(*s)++;
		if (ft_isdigit(**s))
		{
			options -> precision = ft_atoi(*s);
			while (ft_isdigit(**s))
				(*s)++;
		}
		else if (**s == '*')
		{
			(*s)++;
			options -> precision = va_arg(args, int);
			options -> flag_zero = true;
		}
	}
}
