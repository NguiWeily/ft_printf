/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_x.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 16:06:53 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 16:06:56 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include "myutils.h"

char	*conversion_x(unsigned int nb, int is_upper)
{
	char	*hex;

	hex = my_ith(nb);
	if (!hex)
		return (NULL);
	if (is_upper)
		hex = my_strtoupper(hex);
	return (hex);
}
