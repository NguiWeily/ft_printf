/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_s.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:39:53 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:39:55 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_s(va_list args, t_options *options)
{
	char	*s;

	s = va_arg(args, char *);
	if (!s)
	{
		s = "(null)";
		if (options -> precision > 0 && options -> precision < 6)
			options -> precision = 0;
	}
	return (ft_put_fmt_str(s, options));
}
