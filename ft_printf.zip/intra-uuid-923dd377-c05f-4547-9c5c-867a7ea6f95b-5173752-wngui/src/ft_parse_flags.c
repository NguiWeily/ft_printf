/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_flags.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:29:52 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:29:56 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

void	ft_parse_flags(const char **s, t_options *options)
{
	while (**s && ft_strchr("-0#+ ", **s))
	{
		if (**s == '-')
			options -> flag_left = true;
		else if (**s == '0')
			options -> flag_zero = true;
		else if (**s == '#')
			options -> flag_hash = true;
		else if (**s == '+')
			options -> flag_sign = true;
		else if (**s == ' ')
			options -> flag_spce = true;
		(*s)++;
	}
}
