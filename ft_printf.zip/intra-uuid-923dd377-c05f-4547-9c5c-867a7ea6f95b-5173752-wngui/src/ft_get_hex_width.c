/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_hex_width.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:29:32 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:29:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

static int	ft_get_hex_width_helper(int offset, t_options *options)
{
	int		width;

	width = 0;
	if (options -> precision >= 0 || options -> flag_zero)
	{
		if (options -> flag_zero)
			options -> flag_left = false;
		if (options -> precision >= 0)
		{
			width = options -> precision;
			if (options -> precision >= options -> width)
			{
				options -> width = options -> precision + offset;
				if (options -> precision == options -> width)
					width = options -> width;
			}
		}
		else
		{
			width = options -> width - offset;
			options -> width = 0;
		}
	}
	return (width);
}

int	ft_get_hex_width(bool gtzero, t_options *options)
{
	int		width;
	int		offset;

	offset = 0;
	if (gtzero && options -> flag_hash)
		offset = 2;
	width = ft_get_hex_width_helper(offset, options);
	return (width);
}
