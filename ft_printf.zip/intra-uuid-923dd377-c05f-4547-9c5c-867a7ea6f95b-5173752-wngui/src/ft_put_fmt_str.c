/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_str.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:32:29 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:32:32 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_str(char *str, t_options *options)
{
	int		len;

	len = ft_put_var_str(str, options -> precision, true);
	options -> width -= len;
	len = ft_put_fmt_pad(options, true);
	len += ft_put_var_str(str, options -> precision, false);
	return (len);
}
