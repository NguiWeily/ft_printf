/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_c.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:38:40 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:38:42 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_c(va_list args, t_options *options)
{
	char	c;
	int		len;

	len = 1;
	c = va_arg(args, int);
	options -> width--;
	len += ft_put_fmt_pad(options, true);
	ft_put_var_char(c);
	return (len);
}
