/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_pct.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:36:19 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:36:22 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_pct(
		va_list __attribute__((unused)) args,
		t_options *options
	)
{
	ft_put_var_char('%');
	options -> width = 0;
	return (1);
}
