/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_options.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:37:48 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:37:58 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

void	ft_init_options(t_options *options)
{
	options -> flag_left = false;
	options -> flag_zero = false;
	options -> flag_sign = false;
	options -> flag_hash = false;
	options -> flag_spce = false;
	options -> precision = -1;
	options -> width = 0;
}
