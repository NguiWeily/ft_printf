/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_d_i.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:30:39 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:30:43 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_d_i(va_list args, t_options *options)
{
	int		d_i;
	int		len;
	char	prefix;
	int		width;

	d_i = va_arg(args, int);
	if (d_i == 0 && options -> precision == 0)
		width = -1;
	else
		width = ft_get_int_width(d_i < 0, options);
	prefix = '\0';
	if (d_i < 0)
		prefix = '-';
	else
	{
		if (options -> flag_sign)
			prefix = '+';
		else if (options -> flag_spce)
			prefix = ' ';
	}
	len = ft_put_var_int(d_i, prefix, width, true);
	options -> width -= len;
	len = ft_put_fmt_pad(options, true);
	len += ft_put_var_int(d_i, prefix, width, false);
	return (len);
}
