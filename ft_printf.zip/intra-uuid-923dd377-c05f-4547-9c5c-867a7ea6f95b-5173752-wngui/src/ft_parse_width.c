/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_width.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:38:16 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:38:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

void	ft_parse_width(const char **s, t_options *options)
{
	if (ft_isdigit(**s))
	{
		options -> width = ft_atoi(*s);
		while (ft_isdigit(**s))
			*s = *s + 1;
	}
}
