/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_func.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:35:17 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:35:21 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	(*ft_put_fmt_func(
			char c,
			t_options *options
		))(va_list args, t_options *options)
{
	if (c == 'd' || c == 'i')
		return (&ft_put_fmt_d_i);
	if (c == 'u')
		return (&ft_put_fmt_u);
	if (c == 'x')
		return (&ft_put_fmt_x);
	if (c == 'X')
		return (&ft_put_fmt_x_cap);
	options -> flag_zero = false;
	if (c == '%')
		return (&ft_put_fmt_pct);
	if (c == 'c')
		return (&ft_put_fmt_c);
	if (c == 's')
		return (&ft_put_fmt_s);
	if (c == 'p')
		return (&ft_put_fmt_p);
	return (NULL);
}
