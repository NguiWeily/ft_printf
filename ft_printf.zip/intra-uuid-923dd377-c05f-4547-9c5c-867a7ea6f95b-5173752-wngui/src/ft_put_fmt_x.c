/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_x.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:40:19 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:40:22 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_put_fmt_x(va_list args, t_options *options)
{
	unsigned long	x;
	int				len;
	int				width;

	len = 0;
	x = va_arg(args, unsigned int);
	if (x == 0 && options -> precision == 0)
		width = -1;
	else
		width = ft_get_hex_width(x > 0, options);
	len += ft_put_var_hex(x, width, false, true);
	options -> width -= len;
	if (x > 0 && options -> flag_hash)
		options -> width -= 2;
	len = ft_put_fmt_pad(options, true);
	if (x > 0 && options -> flag_hash)
	{
		ft_put_var_str("0x", -1, false);
		len += 2;
	}
	len += ft_put_var_hex(x, width, false, false);
	return (len);
}
