/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:34:42 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:34:45 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

static int	ft_put_fmt_unhandled(const char *s0, const char *s1)
{
	int	len;
	int	range;

	len = -1;
	range = s1 - s0;
	while (++len <= range)
		ft_put_var_char(s0[len]);
	return (len);
}

int	ft_put_fmt(const char **s, va_list args)
{
	const char	*s0;
	int			(*ft_put)(va_list args, t_options *options);
	int			len;
	t_options	options;

	s0 = (*s)++;
	ft_init_options(&options);
	ft_parse_flags(s, &options);
	ft_parse_width(s, &options);
	ft_parse_precision(s, args, &options);
	if (!**s)
		return (-1);
	ft_put = ft_put_fmt_func(**s, &options);
	if (!ft_put)
		return (ft_put_fmt_unhandled(s0, *s));
	len = ft_put(args, &options);
	len += ft_put_fmt_pad(&options, false);
	return (len);
}
