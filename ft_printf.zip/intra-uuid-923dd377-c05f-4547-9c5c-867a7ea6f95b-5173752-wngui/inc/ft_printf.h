/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:25:45 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:25:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <stdbool.h>
# include <stddef.h>
# include <unistd.h>
# include "../libft/libft.h"

typedef struct s_options
{
	bool	flag_left;
	bool	flag_zero;
	bool	flag_sign;
	bool	flag_hash;
	bool	flag_spce;
	int		precision;
	int		width;
}	t_options;

int		ft_get_hex_width(bool gtzero, t_options *options);
int		ft_get_int_width(bool negative, t_options *options);
void	ft_init_options(t_options *options);
void	ft_parse_flags(const char **s, t_options *options);
void	ft_parse_precision(const char **s, va_list args, t_options *options);
void	ft_parse_width(const char **s, t_options *options);
int		ft_printf(const char *s, ...);
int		ft_put_fmt(const char **s, va_list args);
int		ft_put_fmt_c(va_list args, t_options *options);
int		ft_put_fmt_d_i(va_list args, t_options *options);
int	(*ft_put_fmt_func(
				char c,
				t_options *options
				))(va_list args, t_options *options);
int		ft_put_fmt_p(va_list args, t_options *options);
int		ft_put_fmt_pad(t_options *options, bool left);
int		ft_put_fmt_pct(va_list args, t_options *options);
int		ft_put_fmt_s(va_list args, t_options *options);
int		ft_put_fmt_str(char *str, t_options *options);
int		ft_put_fmt_u(va_list args, t_options *options);
int		ft_put_fmt_x(va_list args, t_options *options);
int		ft_put_fmt_x_cap(va_list args, t_options *options);
void	ft_put_var_char(char c);
int		ft_put_var_hex(unsigned long var, int width, bool capital, bool silent);
int		ft_put_var_int(int var, char prefix, int width, bool silent);
int		ft_put_var_int_unsigned(unsigned int var, int width, bool silent);
int		ft_put_var_str(char *s, int precision, bool silent);

#endif
