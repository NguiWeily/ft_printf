/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_d_i.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:30:39 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:30:43 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_d_i(va_list args, t_options *options)
{
    int d_i;
    int len;
    char prefix;
    int width;

    d_i = va_arg(args, int);
    // Retrieve the integer argument from the variable argument list using va_arg.

    if (d_i == 0 && options->precision == 0)
        width = -1;
    else
        width = ft_get_int_width(d_i < 0, options);
    // Determine the minimum field width based on the integer value 'd_i' and formatting options.

    prefix = '\0';
    // Initialize 'prefix' to '\0', which represents no prefix by default.

    if (d_i < 0)
        prefix = '-';
    // If 'd_i' is negative, set 'prefix' to '-' to indicate a negative number.

    else
    {
        if (options->flag_sign)
            prefix = '+';
        // If the 'flag_sign' is set, set 'prefix' to '+' to indicate a positive number with a sign.

        else if (options->flag_spce)
            prefix = ' ';
        // If the 'flag_spce' is set, set 'prefix' to ' ' to indicate a positive number with a space.
    }

    len = ft_put_var_int(d_i, prefix, width, true);
    // Calculate the length of the integer representation with optional prefix and width.

    options->width -= len;
    // Adjust the remaining width after printing the integer.

    len = ft_put_fmt_pad(options, true);
    // Calculate padding and update 'len' with the number of characters printed.

    len += ft_put_var_int(d_i, prefix, width, false);
    // Print the formatted integer (with prefix) and update 'len'.

    return (len);
    // Return the total number of characters printed.
}
