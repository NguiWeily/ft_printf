/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_int_unsigned.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:37:30 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:37:33 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_var_int_unsigned(unsigned int var, int width, bool silent)
{
    int len;
    // Initialize 'len' to 0, which represents the current length of characters printed.

    if (var == 0 && width < 0)
        return (0);
    // If 'var' is 0 and 'width' is negative, return 0, indicating that no characters will be printed.

    len = 0;
    // Initialize 'len' to 0, which represents the current length of characters printed.

    if (width > 0)
        width -= ft_put_var_int_unsigned(var, 0, true);
    // If 'width' is positive, subtract the number of characters printed by calling 'ft_put_var_int_unsigned' with 'silent' as true from 'width'.

    while (width-- > 0)
    {
        if (!silent)
            ft_put_var_char('0');
        // If 'silent' is not true, print '0' and increment 'len'.
        len++;
    }

    if (var >= 10)
        len += ft_put_var_int_unsigned(var / 10, 0, silent);
    // If 'var' is greater than or equal to 10, recursively call 'ft_put_var_int_unsigned' with 'var / 10' to print the remaining digits. Increment 'len' by the number of characters printed in this step.

    if (!silent)
        ft_put_var_char((char)(var % 10 + '0'));
    // If 'silent' is not true, print the last digit of 'var' by converting it to a character and increment 'len'.

    return (len + 1);
    // Return 'len + 1' to account for the last digit printed.
}
