/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_int.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:33:15 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:33:18 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_var_int(int var, char prefix, int width, bool silent)
{
    int len;
    unsigned int var_unsigned;

    len = 0;
    // Initialize 'len' to 0, which represents the current length of characters printed.

    var_unsigned = var;
    // Initialize 'var_unsigned' to 'var', treating it as an unsigned integer initially.

    if (var < 0)
        var_unsigned = -var;
    // If 'var' is negative, convert it to its absolute value by negating it and storing it in 'var_unsigned'.

    if (prefix)
    {
        if (!silent)
            ft_put_var_char(prefix);
        // If 'prefix' is true and 'silent' is not true, print the 'prefix' character.
        len++;
        // Increment 'len' to account for the character printed as the prefix.
        if (width > 0)
            width--;
        // If 'width' is positive, decrement it to account for the character printed as the prefix.
    }

    len += ft_put_var_int_unsigned(var_unsigned, width, silent);
    // Call 'ft_put_var_int_unsigned' to print the unsigned integer 'var_unsigned' with the specified 'width' and 'silent' flag.
    // Increment 'len' by the number of characters printed in this step.

    return (len);
    // Return 'len', which represents the total number of characters printed for the formatted integer.
}
