/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_s.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:39:53 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:39:55 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_s(va_list args, t_options *options)
{
    char *s;

    s = va_arg(args, char *);
    // Retrieve the string argument from the variable argument list.

    if (!s)
    {
        s = "(null)";
        // If the string is NULL, set 's' to "(null)" to print as the default value.

        if (options->precision > 0 && options->precision < 6)
            options->precision = 0;
        // If the 'precision' option is set to a positive value less than 6, reset it to 0.
    }

    return (ft_put_fmt_str(s, options));
    // Call 'ft_put_fmt_str' to format and print the string 's' with the specified 'options'.
}
