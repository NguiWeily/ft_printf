/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_char.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:37:04 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:37:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_put_var_char(char c)
{
    write(1, &c, 1);
    // Use the 'write' function to write a single character 'c' to the standard output (file descriptor 1).
    // The second argument is the address of the character, and the third argument is the number of bytes to write (1 byte for a single character).
}
