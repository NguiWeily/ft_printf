/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_pct.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:36:19 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:36:22 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_pct(
    va_list __attribute__((unused)) args,
    t_options *options
)
{
    // This function handles the '%' format specifier. It does not use the 'args' parameter,
    // hence the '__attribute__((unused))' attribute to avoid a compilation warning.

    ft_put_var_char('%');
    // Print a '%' character using 'ft_put_var_char'.

    options->width = 0;
    // Set the 'width' option to 0, as '%' format specifier does not consume any additional width.

    return (1);
    // Return 1 to indicate that one '%' character was printed.
}
