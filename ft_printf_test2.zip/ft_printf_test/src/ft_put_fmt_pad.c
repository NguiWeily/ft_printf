/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_pad.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:39:14 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:39:20 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_pad(t_options *options, bool left)
{
    int len;

    if (left && options->flag_left)
        return (0);
    // If 'left' is true (indicating left alignment) and the 'flag_left' option is set,
    // return 0 to indicate that no padding is needed on the left side.

    len = 0;
    // Initialize 'len' to 0, which represents the number of characters printed for padding.

    while (options->width-- > 0)
    {
        ft_put_var_char(' ');
        // Print a space character for padding.
        
        len++;
        // Increment 'len' to count the printed space character.

    }
    // Repeat the above block until 'options->width' becomes zero, printing spaces for padding.

    return (len);
    // Return 'len', which represents the total number of characters printed for padding.
}
