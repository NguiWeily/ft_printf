/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_u.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:36:41 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:36:44 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_u(va_list args, t_options *options)
{
    unsigned int u;
    int width;
    int len;

    u = va_arg(args, unsigned int);
    // Retrieve the unsigned integer argument from the variable argument list.

    if (u == 0 && options->precision == 0)
        width = -1;
    // If the unsigned integer 'u' is zero, and 'precision' is set to 0, set 'width' to -1.
    // This means that width is not applied when 'u' is zero and precision is 0.

    else
        width = ft_get_int_width(false, options);
    // Calculate the width (number of characters) required to represent 'u' without any sign.

    len = ft_put_var_int_unsigned(u, width, true);
    // Calculate the length of the formatted unsigned integer and print it.

    options->width -= len;
    // Adjust the remaining 'width' by subtracting the length of the formatted unsigned integer.

    len = ft_put_fmt_pad(options, true);
    // Calculate padding and update 'len' with the number of characters printed for padding.

    len += ft_put_var_int_unsigned(u, width, false);
    // Print the formatted unsigned integer again and update 'len'.

    return (len);
    // Return 'len', which represents the total number of characters printed for the formatted unsigned integer.
}
