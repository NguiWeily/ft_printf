/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_options.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:37:48 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:37:58 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_init_options(t_options *options)
{
    // Initialize formatting options structure with default values.
    
    options->flag_left = false;
    // Set the left-justification flag to false.

    options->flag_zero = false;
    // Set the zero-padding flag to false.

    options->flag_sign = false;
    // Set the flag for displaying the sign of numbers to false.

    options->flag_hash = false;
    // Set the flag for using the '#' character to false.

    options->flag_spce = false;
    // Set the flag for handling the space character to false.

    options->precision = -1;
    // Initialize the precision to -1 (indicating no precision set).

    options->width = 0;
    // Initialize the minimum field width to 0.
}
