/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_str.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:41:03 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:41:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_var_str(char *var, int precision, bool silent)
{
    int len;
    // Initialize 'len' to 0, which represents the current length of characters printed.

    len = 0;
    // Initialize 'len' to 0, which represents the current length of characters printed.

    while (var[len] && (precision < 0 || len < precision))
    {
        // Enter a while loop that iterates through the characters in the 'var' string.
        
        if (!silent)
            ft_put_var_char(var[len]);
        // If 'silent' is not true, print the current character of 'var' and increment 'len'.
        
        len++;
        // Increment 'len' to move to the next character in 'var'.
    }

    return (len);
    // Return 'len', which represents the total number of characters printed.
}
