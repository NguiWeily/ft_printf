/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:34:42 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:34:45 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

static int ft_put_fmt_unhandled(const char *s0, const char *s1)
{
    int len;
    int range;

    len = -1;
    range = s1 - s0;
    // Calculate the range (number of characters) between 's0' and 's1'.

    while (++len <= range)
        ft_put_var_char(s0[len]);
    // Print each character in the specified range using 'ft_put_var_char'.

    return (len);
    // Return the number of characters printed in the range.
}

int ft_put_fmt(const char **s, va_list args)
{
    const char *s0;
    int (*ft_put)(va_list args, t_options *options);
    int len;
    t_options options;

    s0 = (*s)++;
    // Save the current position in the format string as 's0' and increment 's' to the next character.

    ft_init_options(&options);
    // Initialize the 'options' structure with default values.

    ft_parse_flags(s, &options);
    // Parse and set formatting flags in 'options'.

    ft_parse_width(s, &options);
    // Parse and set the minimum field width in 'options'.

    ft_parse_precision(s, args, &options);
    // Parse and set the precision in 'options'.

    if (!**s)
        return (-1);
    // If the current character is '\0', return -1 (indicating an error).

    ft_put = ft_put_fmt_func(**s, &options);
    // Determine the appropriate formatting function based on the current character.

    if (!ft_put)
        return (ft_put_fmt_unhandled(s0, *s));
    // If no formatting function is found, handle it as an unhandled case and print the characters.

    len = ft_put(args, &options);
    // Call the selected formatting function to process the argument and get the printed length.

    len += ft_put_fmt_pad(&options, false);
    // Add padding if necessary and update the total length.

    return (len);
    // Return the total number of characters printed.
}
