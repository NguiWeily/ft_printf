/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_p.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:31:52 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:31:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_p(va_list args, t_options *options)
{
    unsigned long p;
    int len;

    p = va_arg(args, unsigned long long);
    // Retrieve the unsigned long long argument (a pointer address) from the variable argument list.

    if (!p)
        return (ft_put_fmt_str("(nil)", options));
    // If the pointer address 'p' is NULL (zero), print "(nil)" and return its length.

    len = ft_put_var_hex(p, 0, false, true);
    // Calculate the length of the hexadecimal representation of 'p' without any prefix.

    options->width -= len + 2;
    // Adjust the remaining width by subtracting the length of the hexadecimal representation plus 2.

    len = ft_put_fmt_pad(options, true);
    // Calculate padding and update 'len' with the number of characters printed for padding.

    len += ft_put_var_str("0x", -1, false);
    // Print "0x" (hexadecimal prefix) and update 'len'.

    len += ft_put_var_hex(p, 0, false, false);
    // Print the hexadecimal representation of 'p' without a prefix and update 'len'.

    return (len);
    // Return the total number of characters printed.
}
