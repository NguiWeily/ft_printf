/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_func.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:35:17 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:35:21 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int (*ft_put_fmt_func(
            char c,
            t_options *options
        ))(va_list args, t_options *options)
{
    // This function determines and returns a function pointer to the appropriate
    // formatting function based on the character 'c' and formatting 'options'.

    if (c == 'd' || c == 'i')
        return (&ft_put_fmt_d_i);
    // If 'c' is 'd' or 'i', return a pointer to 'ft_put_fmt_d_i' function.

    if (c == 'u')
        return (&ft_put_fmt_u);
    // If 'c' is 'u', return a pointer to 'ft_put_fmt_u' function.

    if (c == 'x')
        return (&ft_put_fmt_x);
    // If 'c' is 'x', return a pointer to 'ft_put_fmt_x' function.

    if (c == 'X')
        return (&ft_put_fmt_x_cap);
    // If 'c' is 'X', return a pointer to 'ft_put_fmt_x_cap' function.

    options->flag_zero = false;
    // Set the 'flag_zero' option to false for unsupported format specifiers.

    if (c == '%')
        return (&ft_put_fmt_pct);
    // If 'c' is '%', return a pointer to 'ft_put_fmt_pct' function.

    if (c == 'c')
        return (&ft_put_fmt_c);
    // If 'c' is 'c', return a pointer to 'ft_put_fmt_c' function.

    if (c == 's')
        return (&ft_put_fmt_s);
    // If 'c' is 's', return a pointer to 'ft_put_fmt_s' function.

    if (c == 'p')
        return (&ft_put_fmt_p);
    // If 'c' is 'p', return a pointer to 'ft_put_fmt_p' function.

    return (NULL);
    // Return NULL for unsupported format specifiers.
}
