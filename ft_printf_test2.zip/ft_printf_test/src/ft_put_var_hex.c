/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_hex.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:40:44 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:40:46 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_var_hex(unsigned long var, int width, bool capital, bool silent)
{
    int len;
    char *charset;

    if (var == 0 && width < 0)
        return (0);
    // Check if 'var' is zero and 'width' is negative; if true, return 0.

    len = 1;
    // Initialize 'len' to 1, which represents the current length of characters printed.

    if (capital)
        charset = "0123456789ABCDEF";
    else
        charset = "0123456789abcdef";
    // Choose the character set for hexadecimal representation based on the 'capital' flag.

    if (width > 0)
        width -= ft_put_var_hex(var, 0, capital, true);
    // If 'width' is positive, subtract the length of the formatted hexadecimal value without printing it from 'width'.

    while (width-- > 0)
    {
        if (!silent)
            ft_put_var_char('0');
        // If 'silent' is not true, print '0' to fill the remaining width.
        len++;
        // Increment 'len' to account for the characters printed in padding.
    }

    if (var >= 16)
        len += ft_put_var_hex(var / 16, 0, capital, silent);
    // Recursively call 'ft_put_var_hex' to print the hexadecimal representation of 'var / 16' if 'var' is greater than or equal to 16.
    
    if (!silent)
        write(1, &charset[var % 16], 1);
    // If 'silent' is not true, write the hexadecimal character corresponding to 'var % 16' to the standard output using the 'write' function.
    
    return (len);
    // Return 'len', which represents the total number of characters printed for the formatted hexadecimal value.
}
