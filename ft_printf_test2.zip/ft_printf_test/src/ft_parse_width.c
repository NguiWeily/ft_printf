/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_width.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:38:16 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:38:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_parse_width(const char **s, t_options *options)
{
    // This function parses and sets the width field in the 'options' structure
    // based on the characters in the string '**s' representing the minimum field width.

    if (ft_isdigit(**s))
    {
        // If the current character is a digit, it indicates the start of the width value.

        options->width = ft_atoi(*s);
        // Set the width to the integer value parsed from the string.

        while (ft_isdigit(**s))
            *s = *s + 1;
        // Continue moving through the string until no more digits are found.
    }
}
