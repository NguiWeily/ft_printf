/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_str.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:32:29 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:32:32 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_str(char *str, t_options *options)
{
    int len;

    len = ft_put_var_str(str, options->precision, true);
    // Calculate the length of the formatted string with 'options->precision' and print it.

    options->width -= len;
    // Adjust the remaining 'width' by subtracting the length of the formatted string.

    len = ft_put_fmt_pad(options, true);
    // Calculate padding and update 'len' with the number of characters printed for padding.

    len += ft_put_var_str(str, options->precision, false);
    // Print the formatted string again and update 'len'.

    return (len);
    // Return the total number of characters printed for the formatted string.
}
