/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:30:08 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:30:11 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_printf(const char *s, ...)
{
    int len;
    int len_inc;
    va_list args;

    len = 0;
    // Initialize the 'len' variable to 0, which will keep track of the total number of characters printed.

    va_start(args, s);
    // Initialize the variable argument list 'args' with 's' as the last named argument.

    while (*s)
    {
        len_inc = 1;
        // Initialize 'len_inc' to 1, which represents the number of characters processed in each iteration.

        if (*s == '%')
            len_inc = ft_put_fmt(&s, args);
        // Check if the current character is '%'. If so, call 'ft_put_fmt' to process the format specifier.

        else
            ft_put_var_char(*s);
        // If the current character is not '%', print it as a regular character using 'ft_put_var_char'.

        if (len_inc < 0)
            len = -1;
        // If 'len_inc' is negative (indicating an error occurred in formatting), set 'len' to -1.

        else if (len >= 0)
            len += len_inc;
        // If 'len' is non-negative (meaning no previous errors occurred), increment 'len' by 'len_inc'.

        s++;
        // Move to the next character in the format string.
    }

    va_end(args);
    // Clean up the variable argument list.

    return (len);
    // Return the total number of characters printed or -1 in case of error.
}
