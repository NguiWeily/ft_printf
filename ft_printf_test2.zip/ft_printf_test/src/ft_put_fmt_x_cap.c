/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_x_cap.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:32:53 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:32:56 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_x_cap(va_list args, t_options *options)
{
    unsigned long x;
    int len;
    int width;

    len = 0;
    // Initialize 'len' to 0; it will keep track of the total characters printed.

    x = va_arg(args, unsigned int);
    // Retrieve the unsigned integer argument 'x' from the variable argument list.

    if (x == 0 && options->precision == 0)
        width = -1;
    // If 'x' is zero and 'precision' is set to zero, set 'width' to -1.
    // This means that width is not applied when 'x' is zero and precision is 0.

    else
        width = ft_get_hex_width(x > 0, options);
    // Calculate the 'width' required to represent 'x' in hexadecimal format, considering the 'flag_hash' option.

    len += ft_put_var_hex(x, width, true, true);
    // Calculate the length of the formatted hexadecimal value in uppercase and print it.
    // The 'true' arguments indicate to calculate and print the length in uppercase.

    options->width -= len;
    // Adjust the remaining 'width' by subtracting the length of the formatted hexadecimal value.

    if (x > 0 && options->flag_hash)
        options->width -= 2;
    // If 'x' is greater than 0 and the 'flag_hash' option is set, subtract 2 from 'width' for the "0X" prefix.

    len = ft_put_fmt_pad(options, true);
    // Calculate padding and update 'len' with the number of characters printed for padding.

    if (x > 0 && options->flag_hash)
    {
        ft_put_var_str("0X", -1, false);
        // Print "0X" as the hexadecimal prefix in uppercase.

        len += 2;
        // Update 'len' to account for the two characters "0X" that were printed.
    }

    len += ft_put_var_hex(x, width, true, false);
    // Print the formatted hexadecimal value again in uppercase, this time without calculating the length.

    return (len);
    // Return 'len', which represents the total number of characters printed for the formatted hexadecimal value in uppercase.
}
