/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_c.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:38:40 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:38:42 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_c(va_list args, t_options *options)
{
    char c;
    int len;

    len = 1;
    // Initialize 'len' to 1, as we will always print at least one character (the character itself).

    c = va_arg(args, int);
    // Retrieve the character argument from the variable argument list using va_arg.

    options->width--;
    // Decrease the width by 1, as we are about to print a character.

    len += ft_put_fmt_pad(options, true);
    // Calculate padding and update 'len' with the number of characters printed.

    ft_put_var_char(c);
    // Print the character using 'ft_put_var_char'.

    return (len);
    // Return the total number of characters printed.
}
