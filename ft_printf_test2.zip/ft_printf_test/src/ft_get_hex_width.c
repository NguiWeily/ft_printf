/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_hex_width.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:29:32 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:29:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

static int ft_get_hex_width_helper(int offset, t_options *options)
{
    int width;

    width = 0;
    // Initialize the 'width' variable to 0.

    if (options->precision >= 0 || options->flag_zero)
    {
        // Check if precision is non-negative or if zero-padding is enabled.
        
        if (options->flag_zero)
            options->flag_left = false;
        // If zero-padding is enabled, clear the left-justification flag.

        if (options->precision >= 0)
        {
            // Check if precision is non-negative.

            width = options->precision;
            // Set 'width' to the precision value.

            if (options->precision >= options->width)
            {
                options->width = options->precision + offset;
                // Adjust the width to be at least the precision plus offset.

                if (options->precision == options->width)
                    width = options->width;
                // If precision equals width, update 'width' accordingly.
            }
        }
        else
        {
            // If precision is negative.

            width = options->width - offset;
            // Set 'width' to the difference between width and offset.
            options->width = 0;
            // Reset 'width' to 0.
        }
    }
    return (width);
    // Return the calculated 'width'.
}

int ft_get_hex_width(bool gtzero, t_options *options)
{
    int width;
    int offset;

    offset = 0;
    // Initialize 'offset' to 0.

    if (gtzero && options->flag_hash)
        offset = 2;
    // If 'gtzero' is true and the '#' flag is enabled, set 'offset' to 2.

    width = ft_get_hex_width_helper(offset, options);
    // Call the helper function to calculate 'width' and store the result.
    
    return (width);
    // Return the calculated 'width'.
}
