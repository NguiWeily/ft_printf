/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_flags.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:29:52 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:29:56 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_parse_flags(const char **s, t_options *options)
{
    // This function parses and sets formatting flags in the 'options' structure
    // based on the characters in the string '**s' until a non-flag character is encountered.

    while (**s && ft_strchr("-0#+ ", **s))
    {
        // The loop continues while the current character is not '\0' (end of string)
        // and it is one of the recognized flag characters: '-', '0', '#', '+', or ' ' (space).

        if (**s == '-')
            options->flag_left = true;
        // If the current character is '-', set the left-justification flag to true.

        else if (**s == '0')
            options->flag_zero = true;
        // If the current character is '0', set the zero-padding flag to true.

        else if (**s == '#')
            options->flag_hash = true;
        // If the current character is '#', set the '#' flag to true.

        else if (**s == '+')
            options->flag_sign = true;
        // If the current character is '+', set the sign flag to true.

        else if (**s == ' ')
            options->flag_spce = true;
        // If the current character is ' ', set the space flag to true.

        (*s)++;
        // Move to the next character in the string by incrementing the 's' pointer.
    }
}
