/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_precision.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:34:25 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:34:28 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_parse_precision(const char **s, va_list args, t_options *options)
{
    // This function parses and sets the precision field in the 'options' structure
    // based on the characters in the string '**s' representing the precision.

    if (**s == '.')
    {
        options->precision = 0;
        // Initialize the precision field to 0 (indicating no precision set).
        
        (*s)++;
        // Move to the next character in the string.

        if (ft_isdigit(**s))
        {
            // If the current character is a digit, parse the precision value.

            options->precision = ft_atoi(*s);
            // Set the precision to the integer value parsed from the string.

            while (ft_isdigit(**s))
                (*s)++;
            // Continue moving through the string until no more digits are found.
        }
        else if (**s == '*')
        {
            // If the current character is '*', it means the precision is provided as an argument.

            (*s)++;
            // Move to the next character.

            options->precision = va_arg(args, int);
            // Get the precision value from the variable argument list using va_arg.

            options->flag_zero = true;
            // Set the zero-padding flag to true (as precision is specified).
        }
    }
}
