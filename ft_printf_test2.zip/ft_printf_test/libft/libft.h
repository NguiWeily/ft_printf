/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:26:00 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:26:02 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

# include <stddef.h>  // Include the standard library header for size_t

// Function prototypes

int ft_atoi(const char *nptr);
// Prototype for the custom atoi (ASCII to integer) function.

int ft_isdigit(int c);
// Prototype for the custom isdigit function that checks if a character is a digit.

char *ft_strchr(const char *s, int c);
// Prototype for the custom strchr (string character) function that finds the first occurrence of a character in a string.

#endif
