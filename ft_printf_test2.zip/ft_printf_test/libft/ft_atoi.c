/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:26:21 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:26:32 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include your custom libft library header

int ft_atoi(const char *nptr)
{
    int num;        // Initialize a variable to store the result
    int sign;       // Initialize a variable to store the sign of the number

    num = 0;        // Initialize num to 0
    sign = 1;       // Initialize sign to positive 1 (default sign is positive)

    // Skip leading whitespace characters (spaces, tabs, newline, etc.)
    while (*nptr == ' ' || (*nptr >= '\t' && *nptr <= '\r'))
        nptr++;

    // Check for a sign (+ or -) and update the sign variable accordingly
    if (*nptr == '+' || *nptr == '-')
    {
        if (*nptr == '-')
            sign *= -1;   // If it's a '-', change the sign to negative
        nptr++;           // Move to the next character
    }

    // Process the digits in the string
    while (ft_isdigit(*nptr))  // While the current character is a digit
    {
        num = (num * 10) + (*nptr - '0'); // Convert and add the digit to num
        nptr++;                          // Move to the next character
    }

    return (num * sign);  // Return the final result, considering the sign
}
