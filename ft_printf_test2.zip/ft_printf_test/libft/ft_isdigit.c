/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:26:50 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:26:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_isdigit(int c)
{
    // Check if the character 'c' is a digit (0-9)
    if ((c >= '0' && c <= '9'))
        return (2048); // Return 2048 (or any non-zero value) to indicate that it's a digit

    return (0); // Return 0 if 'c' is not a digit
}
