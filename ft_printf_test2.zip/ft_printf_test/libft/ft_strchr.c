/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:27:11 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:27:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include your custom libft library header

char *ft_strchr(const char *s, int c)
{
    // Iterate through the characters in the string 's' until a null terminator is encountered
    while (*s)
    {
        // Check if the current character matches the integer 'c' (cast to unsigned char)
        if (*s == (unsigned char) c)
            return ((char *)s); // If there's a match, return a pointer to this character
        s++; // Move to the next character in 's'
    }

    // Check if 'c' matches the null terminator at the end of 's'
    if ((unsigned char) c == *s)
        return ((char *)s); // If 'c' matches the null terminator, return a pointer to it

    return (NULL); // If 'c' is not found in 's', return NULL to indicate no match
}
