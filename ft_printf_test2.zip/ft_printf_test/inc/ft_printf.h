/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:25:45 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:25:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>            // Include for variable argument handling
# include <stdbool.h>           // Include for boolean type
# include <stddef.h>            // Include for NULL and size_t
# include <unistd.h>            // Include for write function
# include "../libft/libft.h"   // Include your own libft library header

// Define a structure to hold formatting options
typedef struct s_options
{
    bool flag_left;       // Flag for left-justified output
    bool flag_zero;       // Flag for zero-padding
    bool flag_sign;       // Flag for whether to display the sign of numbers
    bool flag_hash;       // Flag for using the '#' character (used in some conversions)
    bool flag_spce;       // Flag for handling the space character (used in some conversions)
    int precision;        // Precision for floating-point numbers and strings
    int width;            // Minimum field width
} t_options;

// Function prototypes for the printf-like functions
int ft_get_hex_width(bool gtzero, t_options *options);
int ft_get_int_width(bool negative, t_options *options);
void ft_init_options(t_options *options);
void ft_parse_flags(const char **s, t_options *options);
void ft_parse_precision(const char **s, va_list args, t_options *options);
void ft_parse_width(const char **s, t_options *options);
int ft_printf(const char *s, ...);
int ft_put_fmt(const char **s, va_list args);
int ft_put_fmt_c(va_list args, t_options *options);
int ft_put_fmt_d_i(va_list args, t_options *options);
int (*ft_put_fmt_func(char c, t_options *options))(va_list args, t_options *options);
int ft_put_fmt_p(va_list args, t_options *options);
int ft_put_fmt_pad(t_options *options, bool left);
int ft_put_fmt_pct(va_list args, t_options *options);
int ft_put_fmt_s(va_list args, t_options *options);
int ft_put_fmt_str(char *str, t_options *options);
int ft_put_fmt_u(va_list args, t_options *options);
int ft_put_fmt_x(va_list args, t_options *options);
int ft_put_fmt_x_cap(va_list args, t_options *options);
void ft_put_var_char(char c);
int ft_put_var_hex(unsigned long var, int width, bool capital, bool silent);
int ft_put_var_int(int var, char prefix, int width, bool silent);
int ft_put_var_int_unsigned(unsigned int var, int width, bool silent);
int ft_put_var_str(char *s, int precision, bool silent);

#endif
