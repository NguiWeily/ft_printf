/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_width_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:17:14 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:17:17 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_parse_width(const char **s, t_options *options)
{
    if (ft_isdigit(**s))
    // Check if the current character pointed to by **s is a digit (0-9).
    {
        options->width = ft_atoi(*s);
        // If it's a digit, convert the numeric part of the width (if any) to an integer using ft_atoi
        // and assign it to the 'width' member of the 'options' structure.
        while (ft_isdigit(**s))
        // Continue iterating as long as the current character is a digit.
            *s = *s + 1;
        // Increment the pointer **s to move past the numeric characters.
    }
}
