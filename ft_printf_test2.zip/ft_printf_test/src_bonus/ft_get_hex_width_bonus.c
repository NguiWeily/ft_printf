/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_hex_width_bonus.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:41:49 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:41:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

static int ft_get_hex_width_helper(int offset, t_options *options)
{
    int width;

    width = 0;
    // Initialize 'width' to 0.

    if (options->precision >= 0 || options->flag_zero)
    {
        // Check if either precision is non-negative or 'flag_zero' is true.
        
        if (options->flag_zero)
            options->flag_left = false;
        // If 'flag_zero' is true, set 'flag_left' to false, indicating right alignment.

        if (options->precision >= 0)
        {
            // Check if precision is non-negative.
            
            width = options->precision;
            // Set 'width' to the value of 'precision'.

            if (options->precision >= options->width)
            {
                options->width = options->precision + offset;
                // If 'precision' is greater than or equal to 'width', set 'width' to 'precision + offset'.
                
                if (options->precision == options->width)
                    width = options->width;
                // If 'precision' is equal to 'width', update 'width' to match 'width'.
            }
        }
        else
        {
            width = options->width - offset;
            // Set 'width' to 'width - offset', which represents the remaining available width.
            
            options->width = 0;
            // Set 'width' to 0 to indicate that it has been fully utilized.
        }
    }

    return (width);
    // Return the calculated 'width' value.
}

int ft_get_hex_width(bool gtzero, t_options *options)
{
    int width;
    int offset;

    offset = 0;
    // Initialize 'offset' to 0.

    if (gtzero && options->flag_hash)
        offset = 2;
    // If 'gtzero' is true and 'flag_hash' is true, set 'offset' to 2.

    width = ft_get_hex_width_helper(offset, options);
    // Call the 'ft_get_hex_width_helper' function to calculate 'width'.

    return (width);
    // Return the calculated 'width'.
}
