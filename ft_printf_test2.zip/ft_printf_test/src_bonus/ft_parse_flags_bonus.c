/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_flags_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:24:47 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:24:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_parse_flags(const char **s, t_options *options)
{
    while (**s && ft_strchr("-0#+ ", **s))
    // Start a loop that iterates while the current character pointed to by **s is not null ('\0')
    // and the current character is one of the supported flags ('-', '0', '#', '+', ' ').

    {
        if (**s == '-')
        // Check if the current character is '-':

            options->flag_left = true;
        // If it is '-', set the 'flag_left' member of the 'options' structure to true.
        // This indicates that the left-justification flag is present.

        else if (**s == '0')
        // Check if the current character is '0':

            options->flag_zero = true;
        // If it is '0', set the 'flag_zero' member of the 'options' structure to true.
        // This indicates that the zero-padding flag is present.

        else if (**s == '#')
        // Check if the current character is '#':

            options->flag_hash = true;
        // If it is '#', set the 'flag_hash' member of the 'options' structure to true.
        // This indicates that the hash flag is present.

        else if (**s == '+')
        // Check if the current character is '+':

            options->flag_sign = true;
        // If it is '+', set the 'flag_sign' member of the 'options' structure to true.
        // This indicates that the sign flag is present.

        else if (**s == ' ')
        // Check if the current character is a space (' '):

            options->flag_spce = true;
        // If it is a space, set the 'flag_spce' member of the 'options' structure to true.
        // This indicates that the space flag is present.

        (*s)++;
        // Increment the pointer **s to move to the next character in the input string.
    }
}
