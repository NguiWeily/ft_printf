/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_s_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:18:35 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:18:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_s(va_list args, t_options *options)
// Define the 'ft_put_fmt_s' function that takes a 'va_list' 'args' and a 't_options*' structure 'options' as arguments and returns an integer.
{
    char *s;
    // Declare a character pointer 's' to store the string argument.

    s = va_arg(args, char *);
    // Use 'va_arg' to retrieve the next argument from 'args' as a character pointer and assign it to 's'.

    if (!s)
    // Check if 's' is NULL, indicating that a NULL string was passed as an argument.
    {
        s = "(null)";
        // If 's' is NULL, assign the string "(null)" to 's'.

        if (options->precision > 0 && options->precision < 6)
            options->precision = 0;
        // Check if the 'precision' field in the 'options' structure is greater than 0 and less than 6.
        // If so, set 'precision' to 0, effectively limiting the output to an empty string.
    }
    
    return (ft_put_fmt_str(s, options));
    // Return the result of calling 'ft_put_fmt_str' with 's' and 'options' as arguments.
}
