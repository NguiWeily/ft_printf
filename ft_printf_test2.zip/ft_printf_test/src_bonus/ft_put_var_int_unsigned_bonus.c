/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_int_unsigned_bonus.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:58:28 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:58:31 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file that likely contains function prototypes and necessary declarations.

int ft_put_var_int_unsigned(unsigned int var, int width, bool silent)
// Define the 'ft_put_var_int_unsigned' function, which takes an unsigned integer 'var', width, and a silent flag, and returns an integer.
{
    int len;
    // Declare an integer 'len' to keep track of the length.

    if (var == 0 && width < 0)
        return (0);
    // If 'var' is 0 and 'width' is negative, return 0.
    
    len = 0;
    // Initialize 'len' to 0.

    if (width > 0)
        width -= ft_put_var_int_unsigned(var, 0, true);
    // If 'width' is greater than 0, subtract the length of 'var' when printed with 'width' equal to 0 and 'silent' set to true.

    while (width-- > 0)
    {
        if (!silent)
            ft_put_var_char('0');
        // While 'width' is greater than 0, if 'silent' is false, print '0' using 'ft_put_var_char'.
        len++;
        // Increment 'len' to account for the printed '0'.
    }

    if (var >= 10)
        len += ft_put_var_int_unsigned(var / 10, 0, silent);
    // If 'var' is greater than or equal to 10, recursively call 'ft_put_var_int_unsigned' with 'var' divided by 10, 'width' equal to 0, and 'silent' flag, and add the returned length to 'len'.

    if (!silent)
        ft_put_var_char((char)(var % 10 + '0'));
    // If 'silent' is false, print the last digit of 'var' as a character using 'ft_put_var_char'.

    return (len + 1);
    // Return the total length 'len' plus 1 to account for the last digit printed.
}
