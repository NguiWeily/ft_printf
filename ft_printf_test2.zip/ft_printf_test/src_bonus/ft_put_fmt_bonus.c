/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:55:57 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:55:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

static int ft_put_fmt_unhandled(const char *s0, const char *s1)
// Define a static function 'ft_put_fmt_unhandled' that takes two pointers to characters as arguments.
{
    int len;
    // Initialize a variable 'len' to store the length of characters printed.

    int range;
    // Initialize a variable 'range' to store the range between 's0' and 's1'.

    len = -1;
    // Initialize 'len' to -1.

    range = s1 - s0;
    // Calculate the range as the difference between 's1' and 's0'.

    while (++len <= range)
    // Start a loop that iterates from '-1' to 'range'.
    {
        ft_put_var_char(s0[len]);
        // Call 'ft_put_var_char' to print the character at position 'len' in 's0'.
    }

    return (len);
    // Return the total length of characters printed.
}

int ft_put_fmt(const char **s, va_list args)
// Define the 'ft_put_fmt' function that takes a pointer to a pointer to a character 's' and a 'va_list' 'args' as arguments.
{
    const char *s0;
    // Declare a pointer 's0' to store the current position of the format string.

    int (*ft_put)(va_list args, t_options *options);
    // Declare a function pointer 'ft_put' that takes 'va_list' and 't_options*' arguments.

    int len;
    // Initialize a variable 'len' to store the length of characters printed.

    t_options options;
    // Declare a 't_options' structure variable 'options' to hold format options.

    s0 = (*s)++;
    // Initialize 's0' with the current position of the format string and increment the format string pointer 's'.

    ft_init_options(&options);
    // Call 'ft_init_options' to initialize the 'options' structure.

    ft_parse_flags(s, &options);
    // Call 'ft_parse_flags' to parse and set format flags in 'options'.

    ft_parse_width(s, &options);
    // Call 'ft_parse_width' to parse and set the width in 'options'.

    ft_parse_precision(s, args, &options);
    // Call 'ft_parse_precision' to parse and set the precision in 'options' using 'va_list' 'args'.

    if (!**s)
        return (-1);
    // Check if the current character is the end of the format string. If so, return -1 to indicate an error.

    ft_put = ft_put_fmt_func(**s, &options);
    // Call 'ft_put_fmt_func' to get the appropriate function pointer based on the format specifier and 'options'.

    if (!ft_put)
        return (ft_put_fmt_unhandled(s0, *s));
    // If 'ft_put' is NULL (unhandled specifier), call 'ft_put_fmt_unhandled' to print the characters and return its result.

    len = ft_put(args, &options);
    // Call the selected format-specific printing function 'ft_put' with 'args' and 'options' and store the result in 'len'.

    len += ft_put_fmt_pad(&options, false);
    // Add the length of padding to 'len' by calling 'ft_put_fmt_pad'.

    return (len);
    // Return the total length of characters printed.
}
