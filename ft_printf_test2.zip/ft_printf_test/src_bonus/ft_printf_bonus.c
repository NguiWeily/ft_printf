/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:52:39 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:52:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_printf(const char *s, ...)
// Define the ft_printf function that takes a format string 's' and variable number of arguments.
{
    int len;
    // Initialize a variable 'len' to store the total length of characters printed.

    int len_inc;
    // Initialize a variable 'len_inc' to store the length of characters printed in each format specifier.

    va_list args;
    // Declare a variable 'args' of type 'va_list' to hold the variable arguments.

    len = 0;
    // Initialize 'len' to 0.

    va_start(args, s);
    // Initialize 'args' to start processing the variable arguments passed to the function.

    while (*s)
    // Start a loop that iterates through each character in the format string 's'.
    {
        len_inc = 1;
        // Initialize 'len_inc' to 1, assuming that the current character will be printed.

        if (*s == '%')
        // Check if the current character is a '%' indicating the start of a format specifier.
        {
            len_inc = ft_put_fmt(&s, args);
            // If it's a format specifier, call 'ft_put_fmt' to handle it and update 'len_inc' with the number of characters printed for this specifier.
        }
        else
        {
            ft_put_var_char(*s);
            // If it's not a format specifier, call 'ft_put_var_char' to print the character.
        }

        if (len_inc < 0)
            len = -1;
        // If 'len_inc' is negative, set 'len' to -1 to indicate an error.

        else if (len >= 0)
            len += len_inc;
        // If 'len' is non-negative (not an error), add 'len_inc' to 'len' to accumulate the total length printed.

        s++;
        // Move to the next character in the format string.
    }

    va_end(args);
    // End processing of variable arguments.

    return (len);
    // Return the total length of characters printed.
}
