/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_hex_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:20:26 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:20:28 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file that likely contains function prototypes and necessary declarations.

int ft_put_var_hex(unsigned long var, int width, bool capital, bool silent)
// Define the 'ft_put_var_hex' function, which takes several arguments and returns an integer.
{
    int len;
    char *charset;
    // Declare integer 'len' to keep track of the length, and a character pointer 'charset' to store the character set.

    if (var == 0 && width < 0)
        return (0);
    // Check if 'var' is zero and 'width' is less than zero. If so, return 0.

    len = 1;
    // Initialize 'len' to 1, as there is at least one digit in the hexadecimal representation of 'var'.

    if (capital)
        charset = "0123456789ABCDEF";
    else
        charset = "0123456789abcdef";
    // Set the 'charset' pointer based on the value of 'capital'. If 'capital' is true, use uppercase hex digits; otherwise, use lowercase hex digits.

    if (width > 0)
        width -= ft_put_var_hex(var, 0, capital, true);
    // If 'width' is greater than 0, subtract the result of calling 'ft_put_var_hex' recursively from 'width'.

    while (width-- > 0)
    {
        if (!silent)
            ft_put_var_char('0');
        // While 'width' is greater than 0, if 'silent' is false, print '0' using 'ft_put_var_char'.
        len++;
        // Increment 'len' for each '0' printed.
    }

    if (var >= 16)
        len += ft_put_var_hex(var / 16, 0, capital, silent);
    // If 'var' is greater than or equal to 16, recursively call 'ft_put_var_hex' with 'var' divided by 16.

    if (!silent)
        write(1, &charset[var % 16], 1);
    // If 'silent' is false, use the 'write' function to print the corresponding hexadecimal character from 'charset'.

    return (len);
    // Return the total length 'len'.
}
