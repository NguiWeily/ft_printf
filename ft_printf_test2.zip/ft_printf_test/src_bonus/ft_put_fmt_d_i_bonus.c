/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_d_i_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:53:04 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:53:07 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_d_i(va_list args, t_options *options)
// Define the 'ft_put_fmt_d_i' function that takes 'va_list' 'args' and 't_options*' 'options' as arguments.
{
    int d_i;
    // Declare an integer variable 'd_i' to store the integer value to be printed.

    int len;
    // Initialize an integer variable 'len' to store the length of characters printed.

    char prefix;
    // Declare a character variable 'prefix' to store the sign character ('-', '+', or ' ').

    int width;
    // Declare an integer variable 'width' to store the total width of the printed value.

    d_i = va_arg(args, int);
    // Retrieve an integer argument from 'va_list' 'args' and store it in 'd_i'.

    if (d_i == 0 && options->precision == 0)
        width = -1;
    else
        width = ft_get_int_width(d_i < 0, options);
    // Calculate the 'width' based on the integer value and the 'options' structure.
    // If the value is 0 and precision is 0, set 'width' to -1 (indicating no width limit).

    prefix = '\0';
    // Initialize 'prefix' to the null character '\0'.

    if (d_i < 0)
        prefix = '-';
    else
    {
        if (options->flag_sign)
            prefix = '+';
        else if (options->flag_spce)
            prefix = ' ';
    }
    // Determine the sign character ('-', '+', or ' ') based on 'd_i' and 'options'.

    len = ft_put_var_int(d_i, prefix, width, true);
    // Calculate the length of the integer value string (with prefix), accounting for width.

    options->width -= len;
    // Decrement the 'width' field in the 'options' structure to account for the printed value.

    len = ft_put_fmt_pad(options, true);
    // Add the length of padding (if any) to 'len' by calling 'ft_put_fmt_pad' with 'options' and 'true' to indicate left-padding.

    len += ft_put_var_int(d_i, prefix, width, false);
    // Add the length of the integer value string (without padding) to 'len'.

    return (len);
    // Return the total length of characters printed (including padding and integer value).
}
