/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_pct_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:56:58 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:57:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_pct(
    va_list __attribute__((unused)) args,
    t_options *options
)
// Define the 'ft_put_fmt_pct' function that takes a 'va_list' (unused) 'args' and a 't_options*' structure 'options' as arguments and returns an integer.
{
    ft_put_var_char('%');
    // Call 'ft_put_var_char' to print a '%' character, which represents a literal '%' in the format string.

    options->width = 0;
    // Set the 'width' field in the 'options' structure to 0, indicating that there is no width specified for this format specifier.

    return (1);
    // Return 1 to indicate that one character ('%') has been printed.
}
