/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_p_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:53:32 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:53:34 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_p(va_list args, t_options *options)
// Define the 'ft_put_fmt_p' function that takes a 'va_list' 'args' and a 't_options*' structure 'options' as arguments and returns an integer.
{
    unsigned long p;
    // Declare an unsigned long variable 'p' to store the pointer value.

    int len;
    // Declare an integer 'len' to store the length of the printed output.

    p = va_arg(args, unsigned long long);
    // Retrieve the next argument from 'va_list args' and store it in 'p'.
    // The argument is expected to be an unsigned long long integer.

    if (!p)
        return (ft_put_fmt_str("(nil)", options));
    // If 'p' is a NULL pointer, call 'ft_put_fmt_str' to print "(nil)" and return its result.

    len = ft_put_var_hex(p, 0, false, true);
    // Calculate the length of the hexadecimal representation of 'p' with no width restriction.
    // The result is stored in 'len'.

    options->width -= len + 2;
    // Reduce the 'width' field in the 'options' structure by 'len + 2'.
    // 'len + 2' accounts for the "0x" prefix in the output.

    len = ft_put_fmt_pad(options, true);
    // Call 'ft_put_fmt_pad' to pad the output based on the 'options' configuration.
    // The 'true' argument indicates padding on the left side.
    // 'len' is updated with the length of the padding.

    len += ft_put_var_str("0x", -1, false);
    // Call 'ft_put_var_str' to print the "0x" prefix with no precision restriction.
    // The result is added to 'len'.

    len += ft_put_var_hex(p, 0, false, false);
    // Call 'ft_put_var_hex' to print the hexadecimal representation of 'p' with no width restriction.
    // The result is added to 'len'.

    return (len);
    // Return the total length of the printed output.
}
