/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_pad_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:18:07 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:18:10 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_pad(t_options *options, bool left)
// Define the 'ft_put_fmt_pad' function that takes a 't_options*' structure 'options' and a boolean 'left' as arguments and returns an integer.
{
    int len;
    // Declare an integer 'len' to store the length of the printed padding.

    if (left && options->flag_left)
        return (0);
    // Check if 'left' is true and the 'flag_left' field in the 'options' structure is also true.
    // If both conditions are met, return 0 immediately to indicate no padding is needed.

    len = 0;
    // Initialize 'len' to 0, as we haven't added any padding yet.

    while (options->width-- > 0)
    // Start a while loop that runs as long as 'width' in 'options' is greater than 0.
    {
        ft_put_var_char(' ');
        // Call 'ft_put_var_char' to print a space character.
        
        len++;
        // Increment 'len' to track the number of padding characters added.
    }

    return (len);
    // Return the total length of the printed padding.
}
