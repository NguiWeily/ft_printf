/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_u_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:57:33 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:57:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_u(va_list args, t_options *options)
// Define the 'ft_put_fmt_u' function that takes a va_list 'args' and a 't_options*' structure 'options' as arguments and returns an integer.
{
    unsigned int u;
    // Declare an unsigned integer variable 'u' to store the argument provided from the va_list.

    int width;
    // Declare an integer variable 'width' to store the width of the formatted output.

    int len;
    // Declare an integer variable 'len' to store the length of the formatted output.

    u = va_arg(args, unsigned int);
    // Retrieve the unsigned integer argument from the va_list using 'va_arg' and assign it to 'u'.

    if (u == 0 && options->precision == 0)
        width = -1;
    else
        width = ft_get_int_width(false, options);
    // Check if 'u' is zero and 'options->precision' is zero. If both conditions are met, set 'width' to -1 (indicating that no padding is needed). Otherwise, calculate the width using 'ft_get_int_width' for unsigned integers.

    len = ft_put_var_int_unsigned(u, width, true);
    // Calculate the length of the formatted output by calling 'ft_put_var_int_unsigned' with 'u', 'width', and 'true' (indicating silent mode) as arguments, and assign the result to 'len'.

    options->width -= len;
    // Update the 'width' field in the 'options' structure by subtracting 'len'. This adjusts the remaining width for padding.

    len = ft_put_fmt_pad(options, true);
    // Calculate the length of padding required by calling 'ft_put_fmt_pad' with 'options' and 'true' (indicating silent mode) as arguments, and assign the result to 'len'.

    len += ft_put_var_int_unsigned(u, width, false);
    // Calculate the length of the formatted output by calling 'ft_put_var_int_unsigned' again, this time with 'u', 'width', and 'false' (indicating printing mode) as arguments, and add the result to 'len'.

    return (len);
    // Return the total length of the formatted output, including any padding.
}
