/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_options_bonus.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:58:45 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:58:48 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_init_options(t_options *options)
{
    options->flag_left = false;
    // Initialize the 'flag_left' member of the 'options' structure to false.
    
    options->flag_zero = false;
    // Initialize the 'flag_zero' member of the 'options' structure to false.

    options->flag_sign = false;
    // Initialize the 'flag_sign' member of the 'options' structure to false.

    options->flag_hash = false;
    // Initialize the 'flag_hash' member of the 'options' structure to false.

    options->flag_spce = false;
    // Initialize the 'flag_spce' member of the 'options' structure to false.

    options->precision = -1;
    // Initialize the 'precision' member of the 'options' structure to -1.
    // The default value of -1 indicates that precision is not set.

    options->width = 0;
    // Initialize the 'width' member of the 'options' structure to 0.
    // The default width is 0, indicating no specific width is set.
}
