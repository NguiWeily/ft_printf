/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_precision_bonus.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:55:38 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:55:40 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

void ft_parse_precision(const char **s, va_list args, t_options *options)
{
    if (**s == '.')
    // Check if the current character pointed to by **s is a period ('.').
    {
        options->precision = 0;
        // If it is a period, initialize the 'precision' member of the 'options' structure to 0.
        (*s)++;
        // Increment the pointer **s to move to the next character in the input string.

        if (ft_isdigit(**s))
        // Check if the current character is a digit (0-9):
        {
            options->precision = ft_atoi(*s);
            // If it is a digit, convert the numeric part of the precision (if any) to an integer using ft_atoi.
            while (ft_isdigit(**s))
            // Continue iterating as long as the current character is a digit.
                (*s)++;
            // Increment the pointer **s to move past the numeric characters.
        }
        else if (**s == '*')
        // Check if the current character is an asterisk ('*'):
        {
            (*s)++;
            // Increment the pointer **s to move to the next character.

            options->precision = va_arg(args, int);
            // If it is an asterisk, retrieve an integer argument from the variable arguments list (va_list args)
            // using va_arg, and assign it to the 'precision' member of the 'options' structure.
            options->flag_zero = true;
            // Set the 'flag_zero' member of the 'options' structure to true.
        }
    }
}
