/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_char_bonus.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:58:03 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:58:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file that likely contains function prototypes and necessary declarations.

void ft_put_var_char(char c)
// Define the 'ft_put_var_char' function, which takes a character 'c' as an argument and does not return a value (void).
{
    write(1, &c, 1);
    // Use the 'write' function to write the character 'c' to the standard output (file descriptor 1) with a count of 1 byte.
}
