/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_x_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:18:58 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:19:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_x(va_list args, t_options *options)
// Define the 'ft_put_fmt_x' function that takes a va_list 'args' and a 't_options*' structure 'options' as arguments and returns an integer.
{
    unsigned long x;
    // Declare an unsigned long variable 'x' to store the argument provided from the va_list.

    int len = 0;
    // Declare and initialize an integer variable 'len' to store the length of the formatted output.

    x = va_arg(args, unsigned int);
    // Retrieve the unsigned integer argument from the va_list using 'va_arg' and assign it to 'x'.

    int width;
    // Declare an integer variable 'width' to store the width of the formatted output.

    if (x == 0 && options->precision == 0)
        width = -1;
    else
        width = ft_get_hex_width(x > 0, options);
    // Check if 'x' is zero and 'options->precision' is zero. If both conditions are met, set 'width' to -1 (indicating that no padding is needed). Otherwise, calculate the width using 'ft_get_hex_width' for hexadecimal numbers.

    len += ft_put_var_hex(x, width, false, true);
    // Calculate the length of the formatted output by calling 'ft_put_var_hex' with 'x', 'width', 'false' (indicating lowercase hex), and 'true' (indicating silent mode) as arguments, and add the result to 'len'.

    options->width -= len;
    // Update the 'width' field in the 'options' structure by subtracting 'len'. This adjusts the remaining width for padding.

    if (x > 0 && options->flag_hash)
        options->width -= 2;
    // Check if 'x' is greater than zero and the 'flag_hash' option is set. If both conditions are met, subtract 2 from 'options->width' to account for the "0x" prefix.

    len = ft_put_fmt_pad(options, true);
    // Calculate the length of padding required by calling 'ft_put_fmt_pad' with 'options' and 'true' (indicating silent mode) as arguments, and assign the result to 'len'.

    if (x > 0 && options->flag_hash)
    {
        ft_put_var_str("0x", -1, false);
        len += 2;
    }
    // Check if 'x' is greater than zero and the 'flag_hash' option is set. If both conditions are met, print "0x" using 'ft_put_var_str', and add 2 to 'len' to account for the printed prefix.

    len += ft_put_var_hex(x, width, false, false);
    // Calculate the length of the formatted output by calling 'ft_put_var_hex' again, this time with 'x', 'width', 'false' (indicating lowercase hex), and 'false' (indicating printing mode) as arguments, and add the result to 'len'.

    return (len);
    // Return the total length of the formatted output, including any padding and the "0x" prefix.
}
