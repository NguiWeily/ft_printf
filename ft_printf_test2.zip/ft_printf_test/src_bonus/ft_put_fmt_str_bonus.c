/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_str_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:53:59 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:54:01 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_str(char *str, t_options *options)
// Define the 'ft_put_fmt_str' function that takes a character pointer 'str' and a 't_options*' structure 'options' as arguments and returns an integer.
{
    int len;
    // Declare an integer variable 'len' to store the length of the formatted string.

    len = ft_put_var_str(str, options->precision, true);
    // Calculate the length of the formatted string by calling 'ft_put_var_str' with 'str', 'options->precision', and 'true' (indicating silent mode) as arguments, and assign the result to 'len'.

    options->width -= len;
    // Update the 'width' field in the 'options' structure by subtracting 'len'. This adjusts the remaining width for padding.

    len = ft_put_fmt_pad(options, true);
    // Calculate the length of padding required by calling 'ft_put_fmt_pad' with 'options' and 'true' (indicating silent mode) as arguments, and assign the result to 'len'.

    len += ft_put_var_str(str, options->precision, false);
    // Calculate the length of the formatted string by calling 'ft_put_var_str' again, this time with 'str', 'options->precision', and 'false' (indicating printing mode) as arguments, and add the result to 'len'.

    return (len);
    // Return the total length of the formatted string, including any padding.
}
