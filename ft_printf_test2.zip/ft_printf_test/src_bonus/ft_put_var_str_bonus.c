/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_str_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:20:54 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:20:57 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file that likely contains function prototypes and necessary declarations.

int ft_put_var_str(char *var, int precision, bool silent)
// Define the 'ft_put_var_str' function, which takes a string 'var', a precision value, and a silent flag, and returns an integer.
{
    int len;
    // Declare an integer 'len' to keep track of the length.

    len = 0;
    // Initialize 'len' to 0.

    while (var[len] && (precision < 0 || len < precision))
    {
        // Start a while loop that iterates through each character in the 'var' string until it reaches the end ('\0') or the specified precision.

        if (!silent)
            ft_put_var_char(var[len]);
        // If 'silent' is false, print the character at the current 'len' position using 'ft_put_var_char'.
        
        len++;
        // Increment 'len' to move to the next character in the string.
    }

    return (len);
    // Return the total length 'len', which represents the number of characters printed.
}
