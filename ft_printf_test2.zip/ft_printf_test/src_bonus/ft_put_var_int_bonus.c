/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_var_int_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:54:50 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:54:53 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file that likely contains function prototypes and necessary declarations.

int ft_put_var_int(int var, char prefix, int width, bool silent)
// Define the 'ft_put_var_int' function, which takes an integer 'var', a prefix character, width, and a silent flag, and returns an integer.
{
    int len;
    unsigned int var_unsigned;
    // Declare integer 'len' to keep track of the length, and an unsigned integer 'var_unsigned' to store the absolute value of 'var'.

    len = 0;
    // Initialize 'len' to 0.

    var_unsigned = var;
    // Assign the absolute value of 'var' to 'var_unsigned'.

    if (var < 0)
        var_unsigned = -var;
    // If 'var' is negative, set 'var_unsigned' to its absolute value.

    if (prefix)
    {
        if (!silent)
            ft_put_var_char(prefix);
        // If 'prefix' is true and 'silent' is false, print the 'prefix' character using 'ft_put_var_char'.
        len++;
        // Increment 'len' to account for the printed prefix.
        if (width > 0)
            width--;
        // If 'width' is greater than 0, decrement it by 1.
    }

    len += ft_put_var_int_unsigned(var_unsigned, width, silent);
    // Add the length returned by 'ft_put_var_int_unsigned' to 'len'.

    return (len);
    // Return the total length 'len'.
}
