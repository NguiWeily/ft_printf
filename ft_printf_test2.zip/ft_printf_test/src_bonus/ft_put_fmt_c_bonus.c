/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_c_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 17:17:42 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 17:17:45 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int ft_put_fmt_c(va_list args, t_options *options)
// Define the 'ft_put_fmt_c' function that takes 'va_list' 'args' and 't_options*' 'options' as arguments.
{
    char c;
    // Declare a character variable 'c' to store the character to be printed.

    int len;
    // Initialize an integer variable 'len' to store the length of characters printed.

    len = 1;
    // Initialize 'len' to 1 to account for the character to be printed.

    c = va_arg(args, int);
    // Retrieve a character argument from 'va_list' 'args' and store it in 'c'.

    options->width--;
    // Decrement the 'width' field in the 'options' structure to account for the character.

    len += ft_put_fmt_pad(options, true);
    // Add the length of padding (if any) to 'len' by calling 'ft_put_fmt_pad' with 'options' and 'true' to indicate left-padding.

    ft_put_var_char(c);
    // Call 'ft_put_var_char' to print the character 'c'.

    return (len);
    // Return the total length of characters printed (initial 1 + padding + character).
}
