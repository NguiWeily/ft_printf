/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_fmt_func_bonus.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 16:56:27 by wngui             #+#    #+#             */
/*   Updated: 2023/09/25 16:56:30 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
// Include the header file for your printf-like function.

int (*ft_put_fmt_func(char c, t_options *options))(va_list args, t_options *options)
// Define the 'ft_put_fmt_func' function that takes a character 'c' and a 't_options*' structure 'options' as arguments and returns a function pointer.
{
    if (c == 'd' || c == 'i')
        return (&ft_put_fmt_d_i);
    // If 'c' is 'd' or 'i', return a function pointer to 'ft_put_fmt_d_i'.

    if (c == 'u')
        return (&ft_put_fmt_u);
    // If 'c' is 'u', return a function pointer to 'ft_put_fmt_u'.

    if (c == 'x')
        return (&ft_put_fmt_x);
    // If 'c' is 'x', return a function pointer to 'ft_put_fmt_x'.

    if (c == 'X')
        return (&ft_put_fmt_x_cap);
    // If 'c' is 'X', return a function pointer to 'ft_put_fmt_x_cap'.

    options->flag_zero = false;
    // Set the 'flag_zero' field in the 'options' structure to 'false'.

    if (c == '%')
        return (&ft_put_fmt_pct);
    // If 'c' is '%', return a function pointer to 'ft_put_fmt_pct'.

    if (c == 'c')
        return (&ft_put_fmt_c);
    // If 'c' is 'c', return a function pointer to 'ft_put_fmt_c'.

    if (c == 's')
        return (&ft_put_fmt_s);
    // If 'c' is 's', return a function pointer to 'ft_put_fmt_s'.

    if (c == 'p')
        return (&ft_put_fmt_p);
    // If 'c' is 'p', return a function pointer to 'ft_put_fmt_p'.

    return (NULL);
    // If 'c' doesn't match any of the specified cases, return a NULL function pointer.
}
