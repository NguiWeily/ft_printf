/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:39:48 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:39:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include necessary header files for va_list and custom header files "ft_printf.h," "libft.h," and "myutils.h."

#include <stdarg.h>
#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

// Define a static function named "runner" that processes the format string and handles format specifiers and arguments.

static int runner(const char *str, va_list ap);

// Define a static function named "get_format_str" that extracts and processes a format specifier and returns it as a string.

static char *get_format_str(const char *str, va_list ap, t_format *f);

// Define a static function named "print_format" that prints the formatted output based on the format specifier and arguments.

static int print_format(va_list ap, t_format *f);

// Define the "ft_printf" function, which is the main entry point for printf-style formatting.

int ft_printf(const char *str, ...)
{
    va_list ap;
    int len;

    // Check if the input format string 'str' is NULL.
    if (str == NULL)
    {
        return (0);
    }

    // Start the variable argument list with 'ap.'
    va_start(ap, str);

    // Call the "runner" function to process the format string and get the total length of the formatted output.
    len = runner(str, ap);

    // End the variable argument list.
    va_end(ap);

    // Return the total length of the formatted output.
    return (len);
}

// Define the "runner" function, which processes the format string and handles format specifiers and arguments.

static int runner(const char *str, va_list ap)
{
    char *fstr; // Stores the extracted format specifier as a string.
    int len;    // Stores the total length of the formatted output.
    t_format f; // Stores format flags and parameters.

    len = 0;

    // Loop through the input format string 'str.'
    while (*str)
    {
        if (*str == '%')
        {
            // If '%' character is encountered, extract the format specifier using "get_format_str."
            fstr = get_format_str(str, ap, &f);

            if (fstr)
            {
                // Call "print_format" to print the formatted output based on the format specifier and arguments.
                len += print_format(ap, &f);

                // Move the 'str' pointer to skip the processed format specifier.
                str += ft_strlen(fstr);

                // Free the memory allocated for 'fstr.'
                free(fstr);
            }
        }
        else
        {
            // If '%' is not encountered, print the character and increment the length counter.
            ft_putchar_fd(*str, 1);
            len++;
            str++;
        }
    }

    // Return the total length of the formatted output.
    return (len);
}

// Define the "get_format_str" function, which extracts and processes a format specifier and returns it as a string.

static char *get_format_str(const char *str, va_list ap, t_format *f)
{
    int i;
    char *fstr; // Stores the extracted format specifier as a string.

    // Initialize 'fstr' with a '%' character as the first character.
    fstr = set_format_str(NULL, '%', 0);

    if (!fstr)
    {
        return (NULL);
    }

    i = 1;

    // Reset the format flags and parameters in 'f.'
    reset_format(f);

    // Loop through the characters in 'str' starting from index 1 (after '%').
    while (str[i])
    {
        if (!set_format(str[i], ap, f))
        {
            // If a character does not match a format flag or parameter, free 'fstr' and return NULL.
            free(fstr);
            return (NULL);
        }

        // Append the character to 'fstr.'
        fstr = set_format_str(fstr, str[i], i);

        if (!str)
        {
            return (NULL);
        }

        if (f->type)
        {
            // If a valid format specifier type is found, return 'fstr.'
            return (fstr);
        }

        // Increment the index 'i.'
        i++;
    }

    // Free 'fstr' and return NULL if no valid format specifier is found.
    free(fstr);
    return (NULL);
}

// Define the "print_format" function, which prints the formatted output based on the format specifier and arguments.

static int print_format(va_list ap, t_format *f)
{
    char *cstr; // Stores the formatted string.
    int n;      // Stores the length of the formatted output.

    // Call "conversion_type" to convert the argument based on the format specifier and store the result in 'cstr.'
    cstr = conversion_type(ap, f);

    // Apply format flags and parameters to 'cstr.'
    cstr = conversion_flag(cstr, f);
    cstr = conversion_pcs(cstr, f);
    cstr = conversion_width(cstr, f);

    if (f->type == 'c')
    {
        // If the format specifier is 'c,' call "print_char" to print the character with width adjustment.
        n = print_char(cstr, f->width);
    }
    else
    {
        // If the format specifier is not 'c,' call "print_str" to print the string with width adjustment.
        n = print_str(cstr, f);
    }

    // Free the memory allocated for 'cstr.'
    free(cstr);

    // Return the length of the formatted output.
    return (n);
}
