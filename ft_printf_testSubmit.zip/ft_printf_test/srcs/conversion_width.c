/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_width.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:38:49 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:38:51 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

static char	*align_left(char *cstr, t_format *f);
static char	*align_right(char *cstr, t_format *f);
static int	fill_prefix(char *cfstr, int i, int n, t_format *f);

char	*conversion_width(char	*cstr, t_format *f)
{
	char	*cfstr;

	if (f->width <= ft_strlen(cstr))
		return (cstr);
	if (f->minus)
		cfstr = align_left(cstr, f);
	else
		cfstr = align_right(cstr, f);
	if (!cfstr)
		return (NULL);
	return (cfstr);
}

static char	*align_left(char *cstr, t_format *f)
{
	char	*cfstr;
	int		i;
	int		plen;

	i = 0;
	plen = my_printlen(cstr);
	cfstr = ft_calloc(sizeof(char), f->width + 1);
	if (!cfstr)
		return (NULL);
	if (plen == 1 && (f->dot && f->pcs == 0) && (*cstr == '0' || *cstr == 0))
		cfstr[i++] = ' ';
	while (i < f->width)
	{	
		if (i < plen && (f->type == 's' && *cstr == 0))
			cfstr[i] = ' ';
		else if (i < plen)
			cfstr[i] = cstr[i];
		else
			cfstr[i] = ' ';
		i++;
	}
	free(cstr);
	return (cfstr);
}

static char	*align_right(char *cstr, t_format *f)
{
	char	*cfstr;
	int		i;
	int		j;
	int		plen;

	i = 0;
	j = 0;
	cfstr = ft_calloc(sizeof(char), f->width + 1);
	plen = my_printlen(cstr);
	if (!cfstr)
		return (NULL);
	if (cstr[0] == '-' && (f->zero && (!f->dot || f->pcs < 0)))
	{
		cfstr[i++] = cstr[j++];
		f->width++;
	}
	i = fill_prefix(cfstr, i, plen, f);
	if (plen == 1 && (f->dot && f->pcs == 0) && (*cstr == '0' || *cstr == 0))
		cfstr[i++] = ' ';
	while (j < plen)
		cfstr[i++] = cstr[j++];
	free(cstr);
	return (cfstr);
}

static int	fill_prefix(char *cfstr, int i, int n, t_format *f)
{
	while (i < f->width - n)
	{
		if (f->zero && (!f->dot || f->pcs < 0))
			cfstr[i] = '0';
		else
			cfstr[i] = ' ';
		i++;
	}
	return (i);
}
/*// Include necessary header files "ft_printf.h," "libft.h," and "myutils.h."

#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

// Declare three static functions: "align_left," "align_right," and "fill_prefix."

static char *align_left(char *cstr, t_format *f);
static char *align_right(char *cstr, t_format *f);
static int fill_prefix(char *cfstr, int i, int n, t_format *f);

// Define a function "conversion_width" that handles width formatting.

char *conversion_width(char *cstr, t_format *f)
{
    char *cfstr;

    // If the width specified is less than or equal to the length of 'cstr,' no formatting is required.
    if (f->width <= ft_strlen(cstr))
        return (cstr);

    // Determine alignment (left or right) based on the 'minus' flag.
    if (f->minus)
        cfstr = align_left(cstr, f);
    else
        cfstr = align_right(cstr, f);

    // If an error occurred during formatting, return NULL.
    if (!cfstr)
        return (NULL);

    // Return the formatted 'cfstr.'
    return (cfstr);
}

// Define the 'align_left' function that aligns text to the left.

static char *align_left(char *cstr, t_format *f)
{
    char *cfstr;
    int i;
    int plen;

    i = 0;
    plen = my_printlen(cstr);
    cfstr = ft_calloc(sizeof(char), f->width + 1);

    // If allocation fails, return NULL.
    if (!cfstr)
        return (NULL);

    // Check for special case: single-character string with 'dot' and 'pcs' set to 0.
    if (plen == 1 && (f->dot && f->pcs == 0) && (*cstr == '0' || *cstr == 0))
        cfstr[i++] = ' ';

    // Copy characters from 'cstr' to 'cfstr' while aligning to the left.
    while (i < f->width)
    {
        if (i < plen && (f->type == 's' && *cstr == 0))
            cfstr[i] = ' ';
        else if (i < plen)
            cfstr[i] = cstr[i];
        else
            cfstr[i] = ' ';
        i++;
    }

    // Free the original 'cstr' and return the formatted 'cfstr.'
    free(cstr);
    return (cfstr);
}

// Define the 'align_right' function that aligns text to the right.

static char *align_right(char *cstr, t_format *f)
{
    char *cfstr;
    int i;
    int j;
    int plen;

    i = 0;
    j = 0;
    cfstr = ft_calloc(sizeof(char), f->width + 1);
    plen = my_printlen(cstr);

    // If allocation fails, return NULL.
    if (!cfstr)
        return (NULL);

    // Check for special case: negative number, zero padding, and 'dot' or negative 'pcs.'
    if (cstr[0] == '-' && (f->zero && (!f->dot || f->pcs < 0)))
    {
        cfstr[i++] = cstr[j++];
        f->width++;
    }

    // Fill the prefix with appropriate characters.
    i = fill_prefix(cfstr, i, plen, f);

    // Check for another special case: single-character string with 'dot' and 'pcs' set to 0.
    if (plen == 1 && (f->dot && f->pcs == 0) && (*cstr == '0' || *cstr == 0))
        cfstr[i++] = ' ';

    // Copy the remaining characters from 'cstr' to 'cfstr.'
    while (j < plen)
        cfstr[i++] = cstr[j++];

    // Free the original 'cstr' and return the formatted 'cfstr.'
    free(cstr);
    return (cfstr);
}

// Define the 'fill_prefix' function that fills the prefix with appropriate characters.

static int fill_prefix(char *cfstr, int i, int n, t_format *f)
{
    while (i < f->width - n)
    {
        if (f->zero && (!f->dot || f->pcs < 0))
            cfstr[i] = '0';
        else
            cfstr[i] = ' ';
        i++;
    }
    return (i);
}
*/