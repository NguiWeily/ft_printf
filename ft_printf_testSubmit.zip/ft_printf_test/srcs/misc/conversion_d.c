/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_d.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 16:05:50 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 16:05:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the necessary header files "libft.h" and "myutils.h."

#include "libft.h"
#include "myutils.h"

// Define a function "conversion_d" that converts an integer 'd' into a string.

char *conversion_d(int d)
{
    char *str;

    // Use the "ft_itoa" function from the "libft" library to convert the integer 'd' into a string.
    str = ft_itoa(d);

    // Check if the "ft_itoa" function failed to allocate memory for the string. If so, return NULL.
    if (!str)
        return (NULL);

    // Return the created string representation of the integer 'd.'
    return (str);
}
