/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_c.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 16:05:35 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 16:05:38 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the necessary header file "libft.h."

#include "libft.h"

// Define a function "conversion_c" that converts a character 'c' into a string.

char *conversion_c(char c)
{
    char *str;

    // Allocate memory for a string of size 2 (1 for the character and 1 for the null-terminator).
    str = ft_calloc(sizeof(char), 2);

    // Check if memory allocation failed. If so, return NULL.
    if (!str)
        return (NULL);

    // Set the first character of the string to the input character 'c.'
    str[0] = c;

    // Ensure the string is null-terminated by adding a null character at the end.

    // Return the created string.
    return (str);
}
