/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_u.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 16:06:38 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 16:06:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the necessary header files "libft.h" and "myutils.h."
#include "libft.h"
#include "myutils.h"

// Declare a static function "uits" that converts an unsigned integer 'd' into a string representation.
static char *uits(unsigned int d);

// Declare a static function "uilen" that calculates the number of digits in an unsigned integer 'd.'
static int uilen(unsigned int d);

// Define a function "conversion_u" that converts an unsigned integer 'd' into a string representation.

char *conversion_u(unsigned int d)
{
    char *str;

    // Call the "uits" function to convert the unsigned integer 'd' to a string.
    str = uits(d);

    // Check if memory allocation for 'str' was successful.
    if (!str)
        return (NULL);

    // Reverse the string 'str' using the "my_strrev" function.
    my_strrev(str);

    // Return the newly created and reversed string 'str,' which holds the converted content.
    return (str);
}

// Define the "uits" function to convert an unsigned integer 'd' into a string representation.
static char *uits(unsigned int d)
{
    char *str;
    int i;

    i = 0;

    // Calculate the length of the string needed to represent 'd' and allocate memory for 'str.'
    str = ft_calloc(sizeof(char), uilen(d) + 1);

    // Check if memory allocation for 'str' was successful.
    if (!str)
        return (NULL);

    // Initialize the first character of 'str' as '0'.
    str[0] = '0';

    // Convert the unsigned integer 'd' to a string.
    while (d > 0)
    {
        str[i] = (d % 10) + '0'; // Extract the last digit of 'd' and convert it to a character.
        d = d / 10; // Remove the last digit from 'd.'
        i++;
    }

    // Return the string representation of 'd.'
    return (str);
}

// Define the "uilen" function to calculate the number of digits in an unsigned integer 'd.'
static int uilen(unsigned int d)
{
    int i = 0;

    // If 'd' is 0, it has one digit.
    if (d == 0)
        return (1);

    // Count the number of digits in 'd.'
    while (d > 0)
    {
        d = d / 10; // Remove the last digit from 'd.'
        i++;
    }

    // Return the number of digits in 'd.'
    return (i);
}
