/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_x.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 16:06:53 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 16:06:56 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the necessary header files "libft.h" and "myutils.h."
#include "libft.h"
#include "myutils.h"

// Define a function "conversion_x" that converts an unsigned integer 'nb' into a hexadecimal string representation.
// The 'is_upper' parameter determines whether the hexadecimal letters should be in uppercase (1) or lowercase (0).

char *conversion_x(unsigned int nb, int is_upper)
{
    char *hex;

    // Call the "my_ith" function to convert the unsigned integer 'nb' to a hexadecimal string.
    hex = my_ith(nb);

    // Check if memory allocation for 'hex' was successful.
    if (!hex)
        return (NULL);

    // If 'is_upper' is true (1), convert the hexadecimal letters to uppercase using "my_strtoupper" function.
    if (is_upper)
        hex = my_strtoupper(hex);

    // Return the resulting hexadecimal string representation.
    return (hex);
}
