/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_s.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 16:06:24 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 16:06:26 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the necessary header files "ft_printf.h", "libft.h," and "myutils.h."
#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

// Define a function "conversion_s" that converts a C string 's' into a new dynamically allocated string.

char *conversion_s(char *s)
{
    char *str;

    // Check if the input string 's' is not NULL.
    if (s)
    {
        // If 's' is not NULL, allocate memory for a new string 'str' with the same length as 's' plus one (for the null-terminator).
        str = ft_calloc(sizeof(char), ft_strlen(s) + 1);
    }
    else
    {
        // If 's' is NULL, allocate memory for a new string 'str' with a predefined empty string "S_EMPTY."
        str = ft_calloc(sizeof(char), S_EMPTY_L + 1);
    }

    // Check if memory allocation for 'str' was successful.
    if (!str)
        return (NULL);

    // If 's' is not NULL, copy the content of 's' to the new string 'str' using "ft_memcpy."
    if (s)
        str = ft_memcpy(str, s, ft_strlen(s));
    else
    {
        // If 's' is NULL, copy the predefined empty string "S_EMPTY" to 'str.'
        str = ft_memcpy(str, S_EMPTY, S_EMPTY_L);
    }

    // Return the newly created string 'str,' which holds the converted content.
    return (str);
}
