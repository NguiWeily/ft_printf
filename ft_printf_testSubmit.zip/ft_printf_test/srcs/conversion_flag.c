/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_flag.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:37:25 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:37:29 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

static char	*format_plus(char	*cstr, t_format *f);
static char	*format_hash(char	*cstr, t_format *f);

char	*conversion_flag(char	*cstr, t_format *f)
{
	cstr = format_plus(cstr, f);
	if (!cstr)
		return (NULL);
	cstr = format_hash(cstr, f);
	if (!cstr)
		return (NULL);
	return (cstr);
}

static char	*format_plus(char	*cstr, t_format *f)
{
	int		nb;
	char	*cfstr;

	if ((f->plus || f->space) && (f->type == 'd' || f->type == 'i'))
	{
		nb = ft_atoi(cstr);
		if (nb < 0)
			return (cstr);
		cfstr = ft_calloc(sizeof(char), 2);
		if (!cfstr)
			return (NULL);
		if (f->plus)
			cfstr[0] = '+';
		else
			cfstr[0] = ' ';
		cfstr = my_strcat(cfstr, cstr);
		if (!cfstr)
			return (NULL);
		free(cstr);
		return (cfstr);
	}
	return (cstr);
}

static char	*format_hash(char	*cstr, t_format *f)
{
	char	*cfstr;

	if (f->hash && (f->type == 'x' || f->type == 'X'))
	{
		cfstr = ft_calloc(sizeof(char), 3);
		if (!cfstr)
			return (NULL);
		cfstr[0] = '0';
		if (cstr[0] != '0')
		{
			cfstr[1] = f->type;
			cfstr = my_strcat(cfstr, cstr);
			if (!cfstr)
				return (NULL);
		}
		free(cstr);
		return (cfstr);
	}
	return (cstr);
}
/*// Include necessary header files "ft_printf.h," "libft.h," and "myutils.h."

#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

// Declare two static functions "format_plus" and "format_hash."

static char *format_plus(char *cstr, t_format *f);
static char *format_hash(char *cstr, t_format *f);

// Define a function "conversion_flag" that handles formatting flags like '+' and '#' for numeric types.

char *conversion_flag(char *cstr, t_format *f)
{
    // Apply the 'format_plus' function to the input 'cstr' to handle '+' and ' ' (space) flags.
    cstr = format_plus(cstr, f);
    if (!cstr)
        return (NULL);

    // Apply the 'format_hash' function to the modified 'cstr' to handle the '#' flag.
    cstr = format_hash(cstr, f);
    if (!cstr)
        return (NULL);

    // Return the formatted 'cstr.'
    return (cstr);
}

// Define the 'format_plus' function that handles the '+' and ' ' (space) flags for numeric types.

static char *format_plus(char *cstr, t_format *f)
{
    int nb;
    char *cfstr;

    // Check if either '+' or ' ' (space) flag is set and the type is 'd' or 'i.'
    if ((f->plus || f->space) && (f->type == 'd' || f->type == 'i'))
    {
        // Convert 'cstr' to an integer.
        nb = ft_atoi(cstr);

        // If the number is negative, no formatting is needed.
        if (nb < 0)
            return (cstr);

        // Allocate memory for 'cfstr,' a new string with the formatting character.
        cfstr = ft_calloc(sizeof(char), 2);
        if (!cfstr)
            return (NULL);

        // Set the formatting character '+' or ' ' (space) based on the flag.
        if (f->plus)
            cfstr[0] = '+';
        else
            cfstr[0] = ' ';

        // Concatenate the formatting character with the original 'cstr.'
        cfstr = my_strcat(cfstr, cstr);
        if (!cfstr)
            return (NULL);

        // Free the original 'cstr' and return the formatted 'cfstr.'
        free(cstr);
        return (cfstr);
    }

    // If no formatting is needed, return the original 'cstr.'
    return (cstr);
}

// Define the 'format_hash' function that handles the '#' flag for hexadecimal formatting.

static char *format_hash(char *cstr, t_format *f)
{
    char *cfstr;

    // Check if the '#' flag is set and the type is 'x' or 'X' (hexadecimal).
    if (f->hash && (f->type == 'x' || f->type == 'X'))
    {
        // Allocate memory for 'cfstr,' a new string for hexadecimal formatting.
        cfstr = ft_calloc(sizeof(char), 3);
        if (!cfstr)
            return (NULL);

        // Set the '0' prefix for hexadecimal numbers.
        cfstr[0] = '0';

        // Check if the original 'cstr' does not start with '0' (to avoid duplicate '0' characters).
        if (cstr[0] != '0')
        {
            // Set the 'x' or 'X' character based on the type.
            cfstr[1] = f->type;

            // Concatenate the formatting characters with the original 'cstr.'
            cfstr = my_strcat(cfstr, cstr);
            if (!cfstr)
                return (NULL);
        }

        // Free the original 'cstr' and return the formatted 'cfstr.'
        free(cstr);
        return (cfstr);
    }

    // If no formatting is needed, return the original 'cstr.'
    return (cstr);
}
*/