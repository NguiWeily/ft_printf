/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_type.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:37:47 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:37:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include necessary header files for va_list and custom header files "ft_printf.h" and "libft.h."

#include <stdarg.h>
#include "ft_printf.h"
#include "libft.h"

// Define a function named "conversion_type" that handles conversion based on the format specifier type.

char *conversion_type(va_list ap, t_format *f)
{
    char *str;

    // Check the format specifier type and call the appropriate conversion function based on the type.

    if (f->type == 'c')
    {
        // For type 'c' (character), call the conversion function "conversion_c" with an integer argument.
        str = conversion_c(va_arg(ap, int));
    }
    else if (f->type == 's')
    {
        // For type 's' (string), call the conversion function "conversion_s" with a character pointer argument.
        str = conversion_s(va_arg(ap, char *));
    }
    else if (f->type == 'p')
    {
        // For type 'p' (pointer), call the conversion function "conversion_p" with an unsigned long long argument.
        str = conversion_p((unsigned long long)va_arg(ap, void *));
    }
    else if (f->type == 'i' || f->type == 'd')
    {
        // For types 'i' or 'd' (signed integer), call the conversion function "conversion_d" with an integer argument.
        str = conversion_d(va_arg(ap, int));
    }
    else if (f->type == 'u')
    {
        // For type 'u' (unsigned integer), call the conversion function "conversion_u" with an integer argument.
        str = conversion_u(va_arg(ap, int));
    }
    else if (f->type == 'x')
    {
        // For type 'x' (hexadecimal), call the conversion function "conversion_x" with an unsigned integer argument
        // and a flag (0 for lowercase, 1 for uppercase).
        str = conversion_x(va_arg(ap, unsigned int), 0);
    }
    else if (f->type == 'X')
    {
        // For type 'X' (hexadecimal, uppercase), call the conversion function "conversion_x" with an unsigned integer argument
        // and the uppercase flag (1).
        str = conversion_x(va_arg(ap, unsigned int), 1);
    }
    else if (f->type == '%')
    {
        // For type '%', call the conversion function "conversion_c" with '%' as an argument.
        str = conversion_c('%');
    }
    else
    {
        // For any other unsupported type, allocate memory for an empty string.
        str = ft_calloc(sizeof(char), 1);
    }

    // Check if memory allocation was unsuccessful during conversion.
    if (!str)
    {
        return (NULL);
    }

    // Return the resulting string from the conversion.
    return (str);
}
