/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:39:29 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:39:32 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include necessary header files "ft_printf.h" and "libft.h."

#include "ft_printf.h"
#include "libft.h"

// Define a function "print_char" that prints characters with width adjustment.

int print_char(char *cstr, int w)
{
    int i;

    i = 0;

    // If width is zero, set it to 1 to ensure at least one character is printed.
    if (w == 0)
    {
        w = 1;
    }

    // Loop through the characters in 'cstr' up to 'w' and print each character.
    while (i < w)
    {
        write(1, &cstr[i], 1);
        i++;
    }

    // Return the number of characters printed.
    return (i);
}

// Define a function "printf_empty" that handles printing for empty or space characters.

int printf_empty(char *cstr, t_format *f)
{
    int n;

    n = 0;

    // Check if 'cstr' is empty and width is specified.
    if (cstr[0] == 0 && f->width)
    {
        // Print a single space character.
        n = print_char(" ", 1);
    }
    else if (cstr[0] == 0 && f->dot && f->pcs < 0)
    {
        // Print an empty string based on the macro S_EMPTY and its length S_EMPTY_L.
        n = print_char(S_EMPTY, S_EMPTY_L);
    }
    else if (ft_strlen(cstr) > 0 && f->width > 0)
    {
        // If width is specified and 'cstr' is not empty, print spaces to reach the specified width.
        while (n++ < f->width)
        {
            ft_putchar_fd(' ', 1);
        }
        n--; // Decrement 'n' as it was incremented one extra time.

    }

    // Return the number of characters printed.
    return (n);
}

// Define a function "print_str" that prints a string with width adjustment based on format flags and parameters.

int print_str(char *cstr, t_format *f)
{
    int n;

    // Check if the format specifies an empty string or should handle empty characters.
    if ((f->type == 's' && f->dot && f->pcs == 0) || (cstr[0] == 0))
    {
        return (printf_empty(cstr, f));
    }

    // Get the length of the string.
    n = ft_strlen(cstr);

    // Check if width is specified and the string is empty.
    if (f->width > 0 && n == 0)
    {
        // Print 'cstr' with padding spaces to reach the specified width.
        n = print_char(cstr, f->width);
    }
    else
    {
        // Print the string using the ft_putstr_fd function.
        ft_putstr_fd(cstr, 1);
    }

    // Return the number of characters printed.
    return (n);
}
