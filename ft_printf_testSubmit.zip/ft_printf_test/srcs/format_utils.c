/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   format_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:39:06 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:39:09 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include necessary header files for va_list and custom header files "ft_printf.h," "libft.h," and "myutils.h."

#include <stdarg.h>
#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

// Define a function named "is_type" that checks if a character is a valid format specifier type.

int is_type(char c)
{
    char *ptr;

    // Define a pointer 'ptr' to a string containing valid format specifier types (F_TYPE).
    ptr = F_TYPE;

    // Loop through the characters in 'ptr' and check if 'c' matches any of them.
    while (*ptr)
    {
        if (*ptr++ == c)
        {
            // If a match is found, return 1 (true).
            return (1);
        }
    }

    // If 'c' does not match any valid format specifier type, return 0 (false).
    return (0);
}

// Define a function named "set_star" that handles the '*' wildcard in format strings.

int set_star(char c, va_list ap, t_format *f)
{
    int star;

    // Check if 'c' is not equal to '*'.
    if (c != '*')
    {
        // If not '*', return 0 (false).
        return (0);
    }

    // Check if the 'dot' flag is set (precision is being specified).
    if (f->dot)
    {
        // If 'dot' is set, read an integer argument from 'ap' and assign it to 'star' as precision.
        star = (va_arg(ap, int));
        f->pcs = star;
    }
    else
    {
        // If 'dot' is not set, read an integer argument from 'ap' and assign it to 'star' as width.
        star = (va_arg(ap, int));

        // Check if 'star' is negative; if so, set the 'minus' flag and make 'star' positive.
        if (star < 0)
        {
            f->minus = 1;
            star *= -1;
        }

        // Assign 'star' to 'f->width' as width.
        f->width = star;
    }

    // Return 1 (true) to indicate that the '*' has been processed.
    return (1);
}

// Define a function named "set_format" that handles setting various format flags and parameters based on the character 'c'.

int set_format(char c, va_list ap, t_format *f)
{
    // Check if 'c' is a '*' and handle it using the "set_star" function.
    if (set_star(c, ap, f))
    {
        return (1); // Return 1 to indicate that the format has been set.
    }
    else if (f->dot && ft_isdigit(c))
    {
        // Check if 'dot' is set, 'c' is a digit, and set 'c' as part of precision.
        f->pcs = (f->pcs * 10) + (c - '0');
    }
    else if (is_type(c))
    {
        // Check if 'c' is a valid format specifier type and set it as 'f->type.'
        f->type = c;
    }
    else if (c == '-')
    {
        // Set the 'minus' flag.
        f->minus = 1;
    }
    else if (c == '+')
    {
        // Set the 'plus' flag.
        f->plus = 1;
    }
    else if (c == ' ')
    {
        // Increment the 'space' flag count.
        f->space += 1;
    }
    else if (c == '0' && f->width == 0)
    {
        // Set the 'zero' flag if 'c' is '0' and width is not specified.
        f->zero = 1;
    }
    else if (c == '#')
    {
        // Set the 'hash' flag.
        f->hash = 1;
    }
    else if (c == '.')
    {
        // Set the 'dot' flag.
        f->dot = 1;
    }
    else if (ft_isdigit(c))
    {
        // Parse and set digits as part of width.
        f->width = (f->width * 10) + (c - '0');
    }
    else
    {
        // If 'c' does not match any format flag or parameter, return 0 (false).
        return (0);
    }

    // Return 1 (true) to indicate that the format has been set.
    return (1);
}

// Define a function named "reset_format" that resets all format flags and parameters in the 't_format' structure.

void reset_format(t_format *f)
{
    // Set all format flags and parameters to their default values.
    f->minus = 0;
    f->plus = 0;
    f->space = 0;
    f->zero = 0;
    f->hash = 0;
    f->dot = 0;
    f->width = 0;
    f->pcs = 0;
    f->type = 0;
}

// Define a function named "set_format_str" that sets a character 'c' in a format string 'fstr' at position 'i.'

char *set_format_str(char *fstr, char c, int i)
{
    // Check if 'fstr' is NULL and allocate memory for 'fstr' with space for the new character.
    if (!fstr)
    {
        fstr = ft_calloc(sizeof(char), i + 2);
    }
    else
    {
        // If 'fstr' is not NULL, reallocate memory to accommodate the new character.
        fstr = my_realloc(fstr, i + 2);
    }

    // Check if memory allocation was unsuccessful.
    if (!fstr)
    {
        return (NULL);
    }

    // Set the character 'c' in 'fstr' at position 'i.'
    fstr[i] = c;

    // Return the updated 'fstr.'
    return (fstr);
}
