/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_pcs.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:38:27 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:38:31 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

static char	*format_pcs_str(char *cstr, t_format *f);
static char	*format_pcs_digit(char *cstr, t_format *f);
static char	*pcs_digit_operation(char *cstr, t_format *f);
static char	*pcs_digit_fill(char *cfstr, char *cstr, t_format *f);

char	*conversion_pcs(char *cstr, t_format *f)
{
	char	*cfstr;

	if (!f->dot)
		return (cstr);
	if (f->type == 's' || f->type == 'c')
		cfstr = format_pcs_str(cstr, f);
	else
		cfstr = format_pcs_digit(cstr, f);
	if (!cfstr)
		return (NULL);
	return (cfstr);
}

static char	*format_pcs_str(char *cstr, t_format *f)
{
	char	*cfstr;

	if ((f->dot && f->pcs == 0)
		|| (IS_LINUX
			&& (ft_strncmp(cstr, S_EMPTY, S_EMPTY_L) == 0 && f->pcs < 6)))
		cfstr = ft_calloc(sizeof(char), 1);
	else
		cfstr = ft_substr(cstr, 0, f->pcs);
	if (!cfstr)
		return (NULL);
	free(cstr);
	return (cfstr);
}

static char	*format_pcs_digit(char *cstr, t_format *f)
{
	char	*cfstr;

	if (cstr[0] == '0' && f->pcs == 0)
	{
		cfstr = ft_calloc(sizeof(char), f->pcs + 1);
		if (!cfstr)
			return (NULL);
		free(cstr);
		return (cfstr);
	}
	else if (f->pcs >= ft_strlen(cstr))
	{
		cfstr = pcs_digit_operation(cstr, f);
		if (!cfstr)
			return (NULL);
		free(cstr);
		return (cfstr);
	}
	return (cstr);
}

static char	*pcs_digit_operation(char *cstr, t_format *f)
{
	char	*cfstr;

	if (cstr[0] == '-')
	{
		cfstr = ft_calloc(sizeof(char), f->pcs + 2);
		if (!cfstr)
			return (NULL);
		cfstr[0] = '-';
	}
	else
	{
		cfstr = ft_calloc(sizeof(char), f->pcs + 1);
		if (!cfstr)
			return (NULL);
	}
	pcs_digit_fill(cfstr, cstr, f);
	return (cfstr);
}

static char	*pcs_digit_fill(char *cfstr, char *cstr, t_format *f)
{
	int		i;
	int		j;
	int		len;

	len = ft_strlen(cstr);
	i = 0;
	j = 0;
	if (cstr[0] == '-')
	{
		i++;
		j++;
		len--;
		f->pcs++;
	}
	while (i < f->pcs)
	{
		if (i < f->pcs - len)
			cfstr[i] = '0';
		else
			cfstr[i] = cstr[j++];
		i++;
	}
	return (cfstr);
}
/*// Include necessary header files "ft_printf.h," "libft.h," and "myutils.h."

#include "ft_printf.h"
#include "libft.h"
#include "myutils.h"

// Declare four static functions: "format_pcs_str," "format_pcs_digit," "pcs_digit_operation," and "pcs_digit_fill."

static char *format_pcs_str(char *cstr, t_format *f);
static char *format_pcs_digit(char *cstr, t_format *f);
static char *pcs_digit_operation(char *cstr, t_format *f);
static char *pcs_digit_fill(char *cfstr, char *cstr, t_format *f);

// Define a function "conversion_pcs" that handles precision (pcs) formatting.

char *conversion_pcs(char *cstr, t_format *f)
{
    char *cfstr;

    // Check if precision (pcs) formatting is required (i.e., the 'dot' field is set).
    if (!f->dot)
        return (cstr);

    // Determine the type ('s' or 'c') and apply the respective formatting function.
    if (f->type == 's' || f->type == 'c')
        cfstr = format_pcs_str(cstr, f);
    else
        cfstr = format_pcs_digit(cstr, f);

    // If an error occurred during formatting, return NULL.
    if (!cfstr)
        return (NULL);

    // Return the formatted 'cfstr.'
    return (cfstr);
}

// Define the 'format_pcs_str' function that handles precision formatting for string types ('s' or 'c').

static char *format_pcs_str(char *cstr, t_format *f)
{
    char *cfstr;

    // Check if precision (pcs) is 0 or if a specific condition in IS_LINUX is met.
    if ((f->dot && f->pcs == 0) || (IS_LINUX && (ft_strncmp(cstr, S_EMPTY, S_EMPTY_L) == 0 && f->pcs < 6)))
        cfstr = ft_calloc(sizeof(char), 1); // Allocate an empty string.
    else
        cfstr = ft_substr(cstr, 0, f->pcs); // Create a substring of the original string.

    // If an error occurred during allocation, return NULL.
    if (!cfstr)
        return (NULL);

    // Free the original 'cstr' and return the formatted 'cfstr.'
    free(cstr);
    return (cfstr);
}

// Define the 'format_pcs_digit' function that handles precision formatting for numeric types.

static char *format_pcs_digit(char *cstr, t_format *f)
{
    char *cfstr;

    // Check if the original 'cstr' is '0' and precision (pcs) is 0.
    if (cstr[0] == '0' && f->pcs == 0)
    {
        cfstr = ft_calloc(sizeof(char), f->pcs + 1); // Allocate an empty string.
        if (!cfstr)
            return (NULL);
        free(cstr);
        return (cfstr);
    }
    else if (f->pcs >= ft_strlen(cstr))
    {
        cfstr = pcs_digit_operation(cstr, f); // Apply precision formatting for numeric types.
        if (!cfstr)
            return (NULL);
        free(cstr);
        return (cfstr);
    }

    // If no formatting is needed, return the original 'cstr.'
    return (cstr);
}

// Define the 'pcs_digit_operation' function that performs precision formatting for numeric types.

static char *pcs_digit_operation(char *cstr, t_format *f)
{
    char *cfstr;

    // Check if the original 'cstr' is negative (starts with '-') and allocate additional space if necessary.
    if (cstr[0] == '-')
    {
        cfstr = ft_calloc(sizeof(char), f->pcs + 2);
        if (!cfstr)
            return (NULL);
        cfstr[0] = '-'; // Place the negative sign.
    }
    else
    {
        cfstr = ft_calloc(sizeof(char), f->pcs + 1);
        if (!cfstr)
            return (NULL);
    }

    // Fill 'cfstr' with the necessary digits based on precision.
    pcs_digit_fill(cfstr, cstr, f);

    return (cfstr);
}

// Define the 'pcs_digit_fill' function that fills 'cfstr' with the necessary digits based on precision.

static char *pcs_digit_fill(char *cfstr, char *cstr, t_format *f)
{
    int i;
    int j;
    int len;

    len = ft_strlen(cstr);
    i = 0;
    j = 0;

    // Adjust 'i' and 'j' based on the presence of a negative sign.
    if (cstr[0] == '-')
    {
        i++;
        j++;
        len--;
        f->pcs++;
    }

    // Fill 'cfstr' with '0' characters or the original digits as needed.
    while (i < f->pcs)
    {
        if (i < f->pcs - len)
            cfstr[i] = '0';
        else
            cfstr[i] = cstr[j++];
        i++;
    }

    return (cfstr);
}
*/