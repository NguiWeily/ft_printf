/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:51:09 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:51:12 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

int ft_strncmp(const char *str1, const char *str2, size_t n)
{
    size_t i;  // Declare a size_t variable 'i' for iterating through the characters.

    i = 0;  // Initialize 'i' to 0.

    while (i < n)  // Continue the loop until 'i' reaches the specified maximum number of characters 'n'.
    {
        if (*str1 - *str2 != 0)  // Compare the current characters pointed to by 'str1' and 'str2'.
        {
            // If the characters are not equal, return the difference between their ASCII values.
            return ((unsigned char)*str1 - (unsigned char)*str2);
        }
        str1++;  // Move the 'str1' pointer to the next character.
        str2++;  // Move the 'str2' pointer to the next character.
        i++;     // Increment 'i' to keep track of the number of characters compared.
    }

    return (0);  // If the loop completes without finding a difference, return 0 to indicate that the strings are equal up to 'n' characters.
}
