/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:46:03 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:46:07 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

// Declare static function prototypes
static int count_pos(long n);
static char *create_number(char *str, long x, int m);

char *ft_itoa(int n)
{
    int m;      // Declare an integer 'm' to store the length of the resulting string.
    long x;     // Declare a long integer 'x' to store the absolute value of 'n'.
    char *str;  // Declare a pointer to char 'str' to store the resulting string.

    x = (long)n;  // Convert 'n' to a long integer and store it in 'x'.
    m = count_pos(n);  // Calculate the length of the resulting string.
    
    if (n >= 0)
        str = malloc(sizeof(char) * m + 1);  // Allocate memory for the string.
    else
        str = malloc(sizeof(char) * ++m + 1);  // Allocate memory for the string, including space for the negative sign.

    if (!str)  // Check if memory allocation failed.
        return (NULL);  // If allocation fails, return NULL to indicate an error.

    str[0] = 0;  // Initialize the first character of the string to '\0' (null character).

    if (n < 0)
    {
        str[0] = '-';  // If 'n' is negative, set the first character to '-' to represent the negative sign.
        x = x * -1;    // Take the absolute value of 'x'.
    }
    
    str = create_number(str, x, m);  // Create the string representation of 'x'.

    return (str);  // Return a pointer to the resulting string.
}

// Define a static function to create the number part of the string
static char *create_number(char *str, long x, int m)
{
    str[m--] = '\0';  // Null-terminate the string at the end.
    
    if (x == 0)
        str[0] = '0';  // If 'x' is zero, set the first character to '0'.

    while (x > 0)
    {
        str[m--] = (x % 10) + '0';  // Convert the last digit of 'x' to a character and store it in the string.
        x /= 10;  // Remove the last digit from 'x'.
    }

    return (str);  // Return the resulting string.
}

// Define a static function to count the number of digits in a positive number
static int count_pos(long n)
{
    int i = 0;  // Initialize a counter 'i' to 0.

    if (n == 0)
        return (1);  // If 'n' is zero, it has one digit.

    if (n < 0)
        n *= -1;  // If 'n' is negative, take its absolute value.

    while (n > 0)
    {
        n /= 10;  // Remove the last digit from 'n'.
        i++;      // Increment the digit count.
    }

    return (i);  // Return the digit count.
}
