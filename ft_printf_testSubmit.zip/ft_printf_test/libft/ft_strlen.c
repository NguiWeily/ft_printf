/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:46:45 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:46:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

int ft_strlen(const char *str)
{
    int i;  // Declare an integer 'i' to store the length of the string.

    i = 0;  // Initialize 'i' to 0.

    while (*str++ != '\0')  // Loop until the null terminator '\0' is encountered.
    {
        i++;  // Increment 'i' for each character in the string.
    }

    return (i);  // Return the calculated length of the string.
}
