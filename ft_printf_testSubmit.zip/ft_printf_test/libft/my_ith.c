/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_ith.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:47:39 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:47:42 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include user-defined header files "myutils.h" and "libft.h."

#include "myutils.h"
#include "libft.h"

// Declare a static helper function named "baselen" that takes a size_t (nb).
// This function will be defined later in the code.

static int baselen(size_t nb);

// Define a function named "my_ith" that converts a size_t integer 'nb' to a hexadecimal string.

char *my_ith(size_t nb)
{
    // Define a string 'base' containing hexadecimal digits.
    char *base = "0123456789abcdef";
    
    // Declare a character pointer 'str' to store the resulting hexadecimal string.
    char *str;
    
    // Declare an integer 'i' for use in loops.
    int i;

    // Allocate memory for the 'str' string to store the hexadecimal representation of 'nb.'
    // The length of the string is determined by the result of the 'baselen' function plus 1 for the null-terminator.

    str = ft_calloc(sizeof(char), baselen(nb) + 1);

    // Check if memory allocation was successful.
    if (!str)
        return (NULL);

    // Initialize the first character of 'str' to '0'.
    str[0] = '0';

    // Initialize the index 'i' to 0 for use in the following loop.
    i = 0;

    // Convert 'nb' to its hexadecimal representation by repeatedly dividing it by 16
    // and storing the corresponding hexadecimal digit in 'str' until 'nb' becomes zero.

    while (nb > 0)
    {
        str[i] = base[nb % 16];
        nb = nb / 16;
        i++;
    }

    // Reverse the order of characters in 'str' to get the correct hexadecimal representation.
    my_strrev(str);

    // Return the resulting hexadecimal string.
    return (str);
}

// Define the static helper function "baselen" which calculates the length of the hexadecimal representation of 'nb'.

static int baselen(size_t nb)
{
    // Declare an integer 'i' to count the number of digits.
    int i;

    // If 'nb' is zero, return 1 (as "0" is represented with one character).
    if (nb == 0)
        return (1);

    // Initialize 'i' to 0 for use in the following loop.
    i = 0;

    // Count the number of hexadecimal digits by repeatedly dividing 'nb' by 16 until it becomes zero.
    while (nb > 0)
    {
        nb = nb / 16;
        i++;
    }

    // Return the number of digits.
    return (i);
}
