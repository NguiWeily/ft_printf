/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:47:04 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:47:07 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the header file "libft.h" which likely contains function prototypes and
// necessary declarations for functions used in this code.

#include "libft.h"

// Declare a static helper function named "setstr" that takes a pointer to a constant
// character string (s), a pointer to a character string (str), an integer (start),
// and a size_t (n). This function will be defined later in the code.

static char	*setstr(char const *s, char *str, int start, size_t n);

// Define the function "ft_substr" which takes a pointer to a constant character string (s),
// an unsigned integer (start), and a size_t (len).

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	// Declare a variable "slen" of type size_t to store the length of the input string "s".
	// Declare a pointer "str" of type char to store the resulting substring.

	size_t	slen;
	char	*str;

	// Check if the "start" index is greater than the length of the input string "s".
	// If it is, this means there are no characters to extract, so allocate memory for
	// a single null-terminated character and return it as an empty string.

	if (start > (unsigned int)ft_strlen(s))
	{
		str = malloc(sizeof(char) * 1);
		if (!str)
			return (NULL);
		str[0] = '\0';
		return (str);
	}
	else
		// Calculate the length of the substring by subtracting "start" from the length
		// of the input string "s" and store it in "slen".
		slen = ft_strlen(s) - start;

	// If the requested length "len" is smaller than "slen," update "slen" to "len" to
	// ensure we don't create a substring longer than requested.

	if (len < slen)
		slen = len;

	// Allocate memory for the resulting substring "str" with enough space to hold "slen" characters
	// plus one additional character for the null-terminator.

	str = malloc(sizeof(char) * slen + 1);

	// Check if memory allocation was successful.

	if (!str)
		return (NULL);

	// Call the "setstr" function to copy the substring from "s" into "str."
	// This function will set "str" with characters from "s" starting from "start" and
	// copying a maximum of "slen" characters.

	str = setstr(s, str, start, slen);

	// Return the resulting substring.

	return (str);
}

// Define the static helper function "setstr" which copies characters from "s" to "str."

static char	*setstr(char const *s, char *str, int start, size_t n)
{
	// Declare a variable "i" of type size_t to use as an index for iteration.

	size_t	i;

	// Iterate through the characters in "s" starting from the "start" position,
	// and copy them into "str" up to a maximum of "n" characters.

	i = 0;
	while (s[i + start] && i < n)
	{
		str[i] = s[i + start];
		i++;
	}

	// Null-terminate the resulting substring.

	str[i] = '\0';

	// Return the modified "str."

	return (str);
}
