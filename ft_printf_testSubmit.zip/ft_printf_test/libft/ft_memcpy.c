/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:49:40 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:49:42 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

void *ft_memcpy(void *dest, const void *src, size_t n)
{
    unsigned int i;  // Declare an unsigned integer 'i' for iteration.
    char *buf;       // Declare a pointer to char 'buf' for the destination memory.
    char *temp;      // Declare a pointer to char 'temp' for the source memory.

    i = 0;           // Initialize 'i' to 0.
    buf = (char *)dest;  // Cast 'dest' to a pointer to char and assign it to 'buf'.
    temp = (char *)src;   // Cast 'src' to a pointer to char and assign it to 'temp'.

    while (i < n)  // Loop while 'i' is less than the specified size 'n'.
    {
        *buf++ = *temp++;  // Copy the byte from 'temp' to 'buf', and increment both pointers.
        i++;               // Increment 'i' to keep track of the number of copied bytes.
    }

    return dest;  // Return a pointer to the destination memory.
}
