/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:53:25 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:53:27 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include user-defined header files "libft.h" and "myutils.h."

#include "libft.h"
#include "myutils.h"

// Define a function named "my_strrev" that reverses a string 'str' in place.

char *my_strrev(char *str)
{
    // Declare a character 'c' to use for swapping characters during reversal.
    char c;

    // Declare integers 'i' and 'n' to use as indices and to store the length of the string 'str,' respectively.

    int i;
    int n;

    // Check if the input string 'str' is NULL.
    if (!str)
    {
        // If 'str' is NULL, return it as is (no reversal is possible).
        return (str);
    }

    // Initialize 'i' to 0.
    i = 0;

    // Calculate the length of the string 'str' using the 'ft_strlen' function from "libft.h."
    n = ft_strlen(str);

    // Use a loop to reverse the string. Iterate until 'i' reaches half of the string's length 'n / 2.'
    // This loop swaps characters from the beginning and end of the string towards the center.

    while (i < n / 2)
    {
        // Swap the character at position 'n - i - 1' with the character at position 'i.'
        c = str[n - i - 1];
        str[n - i - 1] = str[i];
        str[i] = c;

        // Increment 'i' to continue the reversal process.
        i++;
    }

    // Return the modified 'str' pointer, which now points to the reversed string.
    return (str);
}
