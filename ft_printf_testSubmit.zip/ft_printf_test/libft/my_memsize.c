/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_memsize.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:52:47 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:52:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the standard library header file <stddef.h> to ensure that the 'size_t' type is available.

#include <stddef.h>

// Define a function named "my_memsize" that takes a void pointer 'ptr' as its argument.

size_t my_memsize(void *ptr)
{
    // Declare a character pointer 'str' to store the memory address passed as 'ptr'.
    char *str;

    // Declare a variable 'n' of type 'size_t' to store the size of the memory block.

    size_t n;

    // Initialize 'n' to 0.
    n = 0;

    // Cast the void pointer 'ptr' to a character pointer 'str' to make it easier to manipulate as a string.

    str = (char *)ptr;

    // Use a loop to iterate through the memory block pointed to by 'str' until a null terminator ('\0') is encountered.
    // Increment 'n' for each character in the memory block.

    while (*str++)
    {
        n++;
    }

    // Return the final value of 'n', which represents the size of the memory block.

    return (n);
}
