/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_strtoupper.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:48:45 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:48:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the user-defined header file "libft.h."

#include "libft.h"

// Define a function named "my_strtoupper" that converts a string to uppercase.

char *my_strtoupper(char *str)
{
    // Declare an integer 'i' to use as an index for iterating through the string 'str.'

    int i;

    // Initialize 'i' to 0.
    i = 0;

    // Use a loop to iterate through the characters in the string 'str' until a null terminator ('\0') is encountered.

    while (str[i])
    {
        // Use the 'ft_toupper' function from "libft.h" to convert the current character in 'str' to uppercase.
        str[i] = ft_toupper(str[i]);

        // Increment 'i' to move to the next character in the string.
        i++;
    }

    // Return the modified 'str' pointer, which now points to the string with all characters converted to uppercase.
    return (str);
}
