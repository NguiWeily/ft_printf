/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_realloc.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:53:07 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:53:10 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include user-defined header files "libft.h" and "myutils.h."

#include "libft.h"
#include "myutils.h"

// Define a function named "my_realloc" that takes a pointer 'ptr' and a 'size_t' 'size' as arguments.

void *my_realloc(void *ptr, size_t size)
{
    // Declare a void pointer 'new' to store the new memory block.
    void *new;

    // Declare a 'size_t' variable 'msize' to store the size of the existing memory block 'ptr'.
    size_t msize;

    // Calculate the size of the existing memory block 'ptr' using the 'my_memsize' function from "myutils.h."
    msize = my_memsize(ptr);

    // Check if the requested 'size' is less than or equal to the size of the existing block 'msize.'
    if (size <= msize)
    {
        // If the requested size is smaller or equal to the existing size, no reallocation is needed.
        // Return the original 'ptr' as is.
        return (ptr);
    }

    // Allocate memory for the new block 'new' with the requested 'size' using the 'malloc' function.
    new = malloc(sizeof(char) * size);

    // Check if memory allocation was successful.
    if (!new)
    {
        // If allocation failed, return NULL to indicate an error.
        return (NULL);
    }

    // Initialize the new memory block 'new' with zeros using the 'ft_bzero' function from "libft.h."
    ft_bzero(new, size);

    // Check if 'ptr' is NULL (i.e., there was no previous block to copy).
    if (!ptr)
    {
        // If 'ptr' is NULL, simply return the new block 'new' as is.
        return (new);
    }

    // Copy the contents of the old memory block 'ptr' into the new block 'new'
    // up to the size of the old block 'msize' using the 'ft_memcpy' function from "libft.h."
    ft_memcpy(new, ptr, msize);

    // Free the old memory block 'ptr' to release the memory.
    free(ptr);

    // Set 'ptr' to NULL to avoid any unintended use of the old memory block.
    ptr = NULL;

    // Return the new memory block 'new.'
    return (new);
}
