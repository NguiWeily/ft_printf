/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:44:25 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:45:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

void *ft_calloc(size_t n, size_t size)
{
    void *buf;  // Declare a void pointer 'buf' to store the allocated memory.

    // Allocate memory for an array of 'n' elements, each of 'size' bytes.
    buf = malloc(n * size);

    if (!buf)  // Check if the allocation was successful (if 'buf' is NULL).
        return (NULL);  // If not, return NULL to indicate failure.

    if (buf)  // Check if 'buf' is not NULL (just for additional safety, it should be true at this point).
        ft_bzero(buf, n * size);  // Use ft_bzero to zero-initialize the allocated memory.

    return (buf);  // Return a pointer to the allocated and zero-initialized memory.
}
