/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:49:23 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:49:26 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// This is the function definition for a function named "ft_isdigit".
// It takes one argument, 'c', which is expected to be a character.

int ft_isdigit(char c)
{
    // This line contains the beginning of the function body.
    // It checks if the character 'c' is a digit by comparing it to the ASCII values of '0' and '9'.

    // The expression (c >= '0' && c <= '9') checks if 'c' is greater than or equal to '0' and less than or equal to '9'.
    // If 'c' falls within this range, it is considered a digit, and the expression evaluates to 1 (true).
    // If 'c' is not a digit, the expression evaluates to 0 (false).

    return (c >= '0' && c <= '9');
    // The function returns the result of the above expression, which indicates whether 'c' is a digit or not.
}
