/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:49:06 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:49:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

void ft_bzero(void *s, size_t n)
{
    unsigned int i;  // Declare an unsigned integer variable 'i' for iteration.
    char *buf;       // Declare a pointer to char 'buf' to work with the memory block.

    i = 0;  // Initialize 'i' to 0.
    buf = s;  // Point 'buf' to the start of the memory block 's'.

    while (i < n)  // Loop while 'i' is less than the given size 'n'.
    {
        buf[i++] = '\0';  // Set the current byte in 'buf' to the null character '\0' and increment 'i'.
    }
}
