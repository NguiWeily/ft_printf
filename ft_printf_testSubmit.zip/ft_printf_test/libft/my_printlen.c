/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_printlen.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:47:59 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:48:02 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include the user-defined header file "libft.h."

#include "libft.h"

// Define a function named "my_printlen" that takes a pointer to a character string 'str' as its argument.

int my_printlen(char *str)
{
    // Declare an integer variable 'n' to store the length of the input string.

    int n;

    // Use the 'ft_strlen' function from the "libft" library to calculate the length of the input string 'str'
    // and assign the result to the variable 'n.'

    n = ft_strlen(str);

    // Check if the length 'n' is equal to 0, indicating that the string is empty.

    if (n == 0)
    {
        // If the string is empty, return 1 (indicating a length of 1 to represent the null terminator).
        return (1);
    }
    else
    {
        // If the string is not empty, return the calculated length 'n'.
        return (n);
    }
}
