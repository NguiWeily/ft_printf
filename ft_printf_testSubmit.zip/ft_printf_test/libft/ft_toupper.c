/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:51:34 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:51:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// This is the function definition for a function named "ft_toupper".
// It takes one argument, 'c', which is expected to be an integer representing an ASCII character.

int ft_toupper(int c)
{
    // Check if the integer 'c' represents a lowercase letter in ASCII.
    if (c >= 'a' && c <= 'z')
    {
        // If 'c' is a lowercase letter, subtract 32 from its ASCII value to convert it to uppercase.
        return (c - 32);
    }
    else
    {
        // If 'c' is not a lowercase letter (e.g., it's already uppercase or not a letter),
        // simply return 'c' unchanged.
        return (c);
    }
}
