/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:50:07 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:50:12 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

void ft_putstr_fd(char *s, int fd)
{
    while (*s)  // Loop until the end of the string, i.e., until a null terminator '\0' is encountered.
    {
        ft_putchar_fd(*s++, fd);  // Call ft_putchar_fd to write the current character to the specified file descriptor 'fd'.
    }
}
