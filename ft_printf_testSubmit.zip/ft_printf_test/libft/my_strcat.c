/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:48:24 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:48:26 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Include user-defined header files "libft.h" and "myutils.h."

#include "libft.h"
#include "myutils.h"

// Define a function named "my_strcat" that concatenates two strings 's1' and 's2'.

char *my_strcat(char *s1, char *s2)
{
    // Declare an integer 'i' to use as an index.
    int i;

    // Declare integers 'n1' and 'n2' to store the lengths of 's1' and 's2,' respectively.
    int n1;
    int n2;

    // Initialize 'i' to 0.
    i = 0;

    // Calculate the length of string 's1' using the 'ft_strlen' function from "libft.h."
    n1 = ft_strlen(s1);

    // Calculate the length of string 's2' using the 'ft_strlen' function from "libft.h."
    n2 = ft_strlen(s2);

    // Reallocate memory for 's1' to accommodate the concatenated result.
    // The new size is 'n1 + n2 + 1' to account for the concatenated strings and a null terminator.
    s1 = my_realloc((void *)s1, n1 + n2 + 1);

    // Check if memory allocation was successful.
    if (!s1)
    {
        // If allocation failed, return NULL to indicate an error.
        return (NULL);
    }

    // Advance 'i' to the end of string 's1.'
    while (i < n1)
    {
        i++;
    }

    // Copy the characters from string 's2' into 's1' starting from where 's1' left off.
    while (i < n2 + n1)
    {
        s1[i] = s2[i - n1];
        i++;
    }

    // Null-terminate the resulting concatenated string.
    s1[i] = 0;

    // Return the modified 's1' pointer, which now points to the concatenated string.
    return (s1);
}
