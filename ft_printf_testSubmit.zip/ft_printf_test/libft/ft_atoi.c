/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 15:44:10 by wngui             #+#    #+#             */
/*   Updated: 2023/09/15 15:44:12 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the custom library "libft.h". Make sure it contains necessary function declarations.

int ft_atoi(const char *nb)
{
    int prefix;
    int number;

    number = 0;  // Initialize the variable 'number' to 0.
    
    // Check if the input string is empty or contains an escape character '\e' (not standard).
    if (*nb == '\0' || *nb == '\e')
        return (0);  // If true, return 0.

    while (*nb <= 32)  // Skip whitespace characters (ASCII <= 32).
        nb++;

    if (*nb == '-')  // Check if there's a negative sign '-'.
        prefix = -1;  // If yes, set the prefix to -1.
    else
        prefix = 1;   // Otherwise, set the prefix to 1.

    if (*nb == '-' || *nb == '+')  // If there's a '-' or '+' sign after whitespace, skip it.
        nb++;

    while (ft_isdigit(*nb))  // Loop while the current character is a digit.
    {
        number = (number * 10) + (*nb++ - '0');  // Convert the digit to an integer and accumulate it in 'number'.
    }

    return (prefix * number);  // Multiply the final result by the prefix to get the signed integer value.
}
